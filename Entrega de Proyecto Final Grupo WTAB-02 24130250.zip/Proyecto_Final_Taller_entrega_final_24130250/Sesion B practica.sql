USE taller_mecanico;
UPDATE tipo_servicio SET precio_base = 400 WHERE id_tipo_servicio = 1;