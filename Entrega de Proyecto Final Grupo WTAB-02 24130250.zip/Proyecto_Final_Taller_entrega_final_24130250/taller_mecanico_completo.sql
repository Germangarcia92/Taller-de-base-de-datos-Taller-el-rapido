-- ============================================================
--  taller_mecanico_completo.sql
--  Script completo del Proyecto Final - Taller de Base de Datos
--  Crea la base de datos, tablas, constraints, datos de prueba,
--  roles y usuarios, vistas, funciones, procedimientos y triggers.
--  Ejecutar completo en MySQL Workbench con un usuario administrador.
--  (Equivale a ejecutar 01, 02, 03 y 04 en ese orden.)
-- ============================================================

-- >>>>>>>>>> 01_esquema.sql <<<<<<<<<<
-- ============================================================
--  Proyecto Final - Taller de Base de Datos
--  Tema: Taller mecánico (equipo de 3: 6 tablas)
--  01_esquema.sql : CREATE DATABASE, tablas, constraints, ALTER,
--                   bitácora y vistas.  MySQL 8.x
-- ============================================================
DROP DATABASE IF EXISTS taller_mecanico;
CREATE DATABASE taller_mecanico CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE taller_mecanico;

-- Constraints usados: PRIMARY KEY, FOREIGN KEY (ON DELETE / ON UPDATE),
-- UNIQUE, CHECK y NOT NULL / DEFAULT.

CREATE TABLE tipo_servicio (
  id_tipo_servicio INT AUTO_INCREMENT PRIMARY KEY,
  nombre           VARCHAR(80)   NOT NULL UNIQUE,
  descripcion      VARCHAR(255),
  precio_base      DECIMAL(10,2) NOT NULL,
  duracion_horas   DECIMAL(4,1)  NOT NULL DEFAULT 1.0,
  foto             VARCHAR(120),
  CONSTRAINT ck_servicio_precio   CHECK (precio_base >= 0),
  CONSTRAINT ck_servicio_duracion CHECK (duracion_horas > 0)
);

CREATE TABLE herramienta (
  id_herramienta      INT AUTO_INCREMENT PRIMARY KEY,
  nombre              VARCHAR(80) NOT NULL,
  marca               VARCHAR(50),
  codigo              VARCHAR(20) NOT NULL UNIQUE,
  cantidad_disponible INT NOT NULL DEFAULT 1,
  estado              ENUM('Disponible','En uso','Mantenimiento') NOT NULL DEFAULT 'Disponible',
  foto                VARCHAR(120),
  CONSTRAINT ck_herr_cantidad CHECK (cantidad_disponible >= 0)
);

CREATE TABLE empleado (
  id_empleado        INT AUTO_INCREMENT PRIMARY KEY,
  nombre             VARCHAR(60)  NOT NULL,
  apellidos          VARCHAR(80)  NOT NULL,
  puesto             VARCHAR(60)  NOT NULL,
  telefono           VARCHAR(15),
  email              VARCHAR(100) NOT NULL UNIQUE,
  fecha_contratacion DATE         NOT NULL,
  foto               VARCHAR(120)
);

CREATE TABLE cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(60)  NOT NULL,
  apellidos  VARCHAR(80)  NOT NULL,
  telefono   VARCHAR(15)  NOT NULL,
  email      VARCHAR(100) UNIQUE,
  direccion  VARCHAR(150)
);

CREATE TABLE vehiculo (
  id_vehiculo INT AUTO_INCREMENT PRIMARY KEY,
  id_cliente  INT         NOT NULL,
  placa       VARCHAR(12) NOT NULL UNIQUE,
  marca       VARCHAR(40) NOT NULL,
  modelo      VARCHAR(40) NOT NULL,
  anio        INT         NOT NULL,
  color       VARCHAR(30),
  foto        VARCHAR(120),
  CONSTRAINT ck_vehiculo_anio CHECK (anio BETWEEN 1950 AND 2100),
  -- RESTRICT: un cliente con vehículos registrados no se puede borrar por accidente.
  CONSTRAINT fk_vehiculo_cliente FOREIGN KEY (id_cliente)
    REFERENCES cliente(id_cliente) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Tabla intermedia N:M entre vehiculo y tipo_servicio, con atributos propios
-- (fecha, estado, costo) y el responsable y herramienta que se usan.
CREATE TABLE orden_servicio (
  id_orden         INT AUTO_INCREMENT PRIMARY KEY,
  id_vehiculo      INT  NOT NULL,
  id_tipo_servicio INT  NOT NULL,
  id_empleado      INT  NOT NULL,
  id_herramienta   INT  NULL,
  fecha_ingreso    DATE NOT NULL,
  estado           ENUM('Pendiente','En proceso','Terminado','Entregado') NOT NULL DEFAULT 'Pendiente',
  observaciones    VARCHAR(255),
  -- RESTRICT: no se borra un vehículo, servicio o empleado que tenga órdenes (historial).
  CONSTRAINT fk_orden_vehiculo FOREIGN KEY (id_vehiculo)
    REFERENCES vehiculo(id_vehiculo) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_orden_servicio FOREIGN KEY (id_tipo_servicio)
    REFERENCES tipo_servicio(id_tipo_servicio) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_orden_empleado FOREIGN KEY (id_empleado)
    REFERENCES empleado(id_empleado) ON DELETE RESTRICT ON UPDATE CASCADE,
  -- SET NULL: si una herramienta se da de baja, la orden histórica se conserva.
  CONSTRAINT fk_orden_herramienta FOREIGN KEY (id_herramienta)
    REFERENCES herramienta(id_herramienta) ON DELETE SET NULL ON UPDATE CASCADE
);

-- ---------- ALTER TABLE ----------
ALTER TABLE orden_servicio ADD COLUMN costo DECIMAL(10,2) NOT NULL DEFAULT 0;
ALTER TABLE orden_servicio ADD CONSTRAINT ck_orden_costo CHECK (costo >= 0);
ALTER TABLE herramienta    ADD INDEX idx_herramienta_estado (estado);
ALTER TABLE vehiculo       ADD INDEX idx_vehiculo_marca (marca);
ALTER TABLE cliente        MODIFY telefono VARCHAR(20) NOT NULL;

-- ---------- Bitácora (la llenan los triggers; no cuenta en el mínimo de tablas) ----------
CREATE TABLE bitacora_orden (
  id_bitacora     INT AUTO_INCREMENT PRIMARY KEY,
  id_orden        INT          NOT NULL,
  estado_anterior VARCHAR(20),
  estado_nuevo    VARCHAR(20),
  usuario         VARCHAR(80)  NOT NULL,
  fecha           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Vistas (2.6): la app las usa como fuente de reportes ----------
CREATE VIEW v_ordenes_detalle AS
SELECT o.id_orden, o.fecha_ingreso, o.estado, o.costo,
       v.placa, CONCAT(v.marca,' ',v.modelo) AS vehiculo,
       CONCAT(c.nombre,' ',c.apellidos)      AS cliente,
       s.nombre                              AS servicio,
       CONCAT(e.nombre,' ',e.apellidos)      AS responsable,
       h.nombre                              AS herramienta
FROM orden_servicio o
INNER JOIN vehiculo v       ON v.id_vehiculo = o.id_vehiculo
INNER JOIN cliente c        ON c.id_cliente = v.id_cliente
INNER JOIN tipo_servicio s  ON s.id_tipo_servicio = o.id_tipo_servicio
INNER JOIN empleado e       ON e.id_empleado = o.id_empleado
LEFT  JOIN herramienta h    ON h.id_herramienta = o.id_herramienta;

CREATE VIEW v_vehiculos_cliente AS
SELECT v.id_vehiculo, v.placa, v.marca, v.modelo, v.anio, v.color,
       CONCAT(c.nombre,' ',c.apellidos) AS cliente, c.telefono
FROM vehiculo v
INNER JOIN cliente c ON c.id_cliente = v.id_cliente;

CREATE VIEW v_herramientas_uso AS
SELECT h.id_herramienta, h.nombre, h.marca, h.codigo, h.cantidad_disponible, h.estado,
       COUNT(o.id_orden) AS ordenes_en_proceso
FROM herramienta h
LEFT JOIN orden_servicio o ON o.id_herramienta = h.id_herramienta AND o.estado = 'En proceso'
GROUP BY h.id_herramienta, h.nombre, h.marca, h.codigo, h.cantidad_disponible, h.estado;

-- >>>>>>>>>> 02_datos.sql <<<<<<<<<<
-- ============================================================
--  02_datos.sql : carga inicial (15 registros por tabla)
-- ============================================================
USE taller_mecanico;

-- ---------- DATOS (15 por tabla) ----------
INSERT INTO tipo_servicio (nombre, descripcion, precio_base, duracion_horas) VALUES
('Cambio de aceite','Aceite y filtro',350,0.5),
('Afinación mayor','Bujías, filtros y limpieza de inyectores',1200,3),
('Cambio de frenos','Balatas y rectificado de discos',900,2),
('Alineación y balanceo','Cuatro llantas',600,1.5),
('Cambio de batería','Revisión del sistema de carga',250,0.5),
('Diagnóstico por computadora','Lectura de códigos OBD2',400,1),
('Cambio de llantas','Montaje y balanceo',300,1),
('Suspensión','Revisión y ajuste general',1800,4),
('Cambio de clutch','Kit completo de embrague',3500,6),
('Aire acondicionado','Carga de gas y revisión de fugas',850,2),
('Bomba de agua','Cambio con anticongelante',1400,3),
('Banda de distribución','Kit de distribución',2200,4),
('Escape y silenciador','Reparación o reemplazo',950,2),
('Reparación eléctrica','Cableado, fusibles y luces',700,2),
('Amortiguadores','Cambio de los cuatro',1600,3);

INSERT INTO herramienta (nombre, marca, codigo, cantidad_disponible, estado) VALUES
('Llave de impacto','Dewalt','HR-001',4,'Disponible'),
('Gato hidráulico 3 ton','Truper','HR-002',3,'Disponible'),
('Juego de dados 1/2','Urrea','HR-003',6,'Disponible'),
('Torquímetro','Stanley','HR-004',2,'En uso'),
('Elevador de 2 columnas','Rotary','HR-005',2,'Disponible'),
('Escáner OBD2','Launch','HR-006',3,'Disponible'),
('Multímetro digital','Fluke','HR-007',4,'Disponible'),
('Compresor de aire','Campbell','HR-008',1,'Mantenimiento'),
('Extractor de balatas','Lisle','HR-009',2,'Disponible'),
('Cargador de baterías','Bosch','HR-010',3,'Disponible'),
('Pistola neumática','Ingersoll','HR-011',5,'Disponible'),
('Alineador láser','Hunter','HR-012',1,'Disponible'),
('Desmontadora de llantas','Hofmann','HR-013',1,'En uso'),
('Probador de compresión','Actron','HR-014',2,'Disponible'),
('Juego de llaves españolas','Truper','HR-015',8,'Disponible');

INSERT INTO empleado (nombre, apellidos, puesto, telefono, email, fecha_contratacion) VALUES
('Raúl','Montoya Esquer','Jefe de taller','6441110001','raul.montoya@taller.com','2018-03-12'),
('Iván','Cota Beltrán','Mecánico general','6441110002','ivan.cota@taller.com','2019-06-01'),
('Gabriel','Soto Ibarra','Mecánico general','6441110003','gabriel.soto@taller.com','2019-09-15'),
('Marco','Leyva Duarte','Técnico en frenos','6441110004','marco.leyva@taller.com','2020-01-20'),
('Óscar','Valdez Peña','Técnico eléctrico','6441110005','oscar.valdez@taller.com','2020-05-04'),
('Andrés','Félix Acosta','Alineación y balanceo','6441110006','andres.felix@taller.com','2020-08-17'),
('Emilio','Zazueta Ruiz','Mecánico general','6441110007','emilio.zazueta@taller.com','2021-02-08'),
('Diego','Ochoa Salazar','Técnico en A/C','6441110008','diego.ochoa@taller.com','2021-07-26'),
('Hugo','Bojórquez Lara','Mecánico general','6441110009','hugo.bojorquez@taller.com','2022-01-10'),
('Sergio','Ramírez Cota','Diagnóstico','6441110010','sergio.ramirez@taller.com','2022-04-18'),
('Fabián','Gutiérrez Mena','Ayudante','6441110011','fabian.gutierrez@taller.com','2022-10-03'),
('Tomás','Valenzuela Ríos','Ayudante','6441110012','tomas.valenzuela@taller.com','2023-02-13'),
('Julián','Acuña Torres','Técnico en suspensión','6441110013','julian.acuna@taller.com','2023-06-05'),
('Adrián','Mendívil Cruz','Mecánico general','6441110014','adrian.mendivil@taller.com','2024-01-22'),
('Ximena','Carrillo Vega','Recepción y refacciones','6441110015','ximena.carrillo@taller.com','2024-05-06');

INSERT INTO cliente (nombre, apellidos, telefono, email, direccion) VALUES
('Juan Pablo','Aguirre Lugo','6441001001','juan.aguirre@mail.com','Calle Sonora 120, Col. Centro'),
('María Fernanda','López Ruiz','6441001002','maria.lopez@mail.com','Av. Miguel Alemán 455'),
('Carlos Alberto','Mendoza Páez','6441001003','carlos.mendoza@mail.com','Calle Jalisco 310'),
('Ana Lucía','Valenzuela Cota','6441001004','ana.valenzuela@mail.com','Blvd. Las Torres 88'),
('Luis Enrique','Duarte Soto','6441001005','luis.duarte@mail.com','Calle Guerrero 205'),
('Sofía','Ramírez Cota','6441001006','sofia.ramirez@mail.com','Col. Villa Sonora 14'),
('Jorge Armando','Bojórquez Reyes','6441001007','jorge.bojorquez@mail.com','Calle Hidalgo 67'),
('Daniela','Félix Montoya','6441001008','daniela.felix@mail.com','Fracc. Los Álamos 9'),
('Ricardo','Salazar Ibarra','6441001009','ricardo.salazar@mail.com','Calle Allende 172'),
('Paola','Gutiérrez Leyva','6441001010','paola.gutierrez@mail.com','Col. Nainari 301'),
('Miguel Ángel','Ochoa Zamora','6441001011','miguel.ochoa@mail.com','Calle Morelos 540'),
('Fernanda','Acosta Rivera','6441001012','fernanda.acosta@mail.com','Av. Kino 233'),
('Héctor Manuel','Zazueta Lara','6441001013','hector.zazueta@mail.com','Col. Cumuripa 45'),
('Valeria','Sánchez Peña','6441001014','valeria.sanchez@mail.com','Calle Náinari 18'),
('Roberto Carlos','Beltrán Medina','6441001015','roberto.beltran@mail.com','Calle Tetabiate 76');

INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio, color) VALUES
(1,'SON-101-A','Nissan','Versa',2018,'Blanco'),
(2,'SON-102-B','Toyota','Corolla',2020,'Gris'),
(3,'SON-103-C','Chevrolet','Silverado',2017,'Negro'),
(4,'SON-104-D','Ford','Ranger',2019,'Rojo'),
(5,'SON-105-E','Honda','Civic',2016,'Azul'),
(6,'SON-106-F','Volkswagen','Jetta',2015,'Plata'),
(7,'SON-107-G','Mazda','3',2021,'Rojo'),
(8,'SON-108-H','Kia','Rio',2022,'Blanco'),
(9,'SON-109-J','Nissan','NP300',2014,'Blanco'),
(10,'SON-110-K','Hyundai','Tucson',2019,'Gris'),
(11,'SON-111-L','Toyota','Hilux',2018,'Negro'),
(12,'SON-112-M','Chevrolet','Aveo',2013,'Azul'),
(13,'SON-113-N','Ford','Focus',2012,'Plata'),
(14,'SON-114-P','Honda','CR-V',2020,'Blanco'),
(15,'SON-115-R','Dodge','Ram 1500',2016,'Negro');

INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, id_herramienta, fecha_ingreso, estado, observaciones) VALUES
(1,1,2,1,'2026-10-20','Entregado','Sin novedades'),
(2,3,4,9,'2026-10-22','Entregado','Se cambiaron balatas delanteras'),
(3,2,3,3,'2026-10-25','Terminado','Afinación completa'),
(4,6,10,6,'2026-10-27','Entregado','Falla en sensor de oxígeno'),
(5,4,6,12,'2026-10-29','Entregado','Alineación y balanceo'),
(6,5,5,10,'2026-11-02','Terminado','Batería nueva instalada'),
(7,1,2,1,'2026-11-03','Entregado','Aceite sintético'),
(8,10,8,7,'2026-11-05','En proceso','Revisando fuga de gas'),
(9,9,3,2,'2026-11-06','En proceso','Cliente pide presupuesto del clutch'),
(10,8,13,5,'2026-11-09','En proceso','Ruido en suspensión delantera'),
(11,12,9,3,'2026-11-10','Pendiente','Pendiente de refacciones'),
(12,14,5,7,'2026-11-11','Pendiente','Luces intermitentes fallando'),
(13,13,7,NULL,'2026-11-12','Pendiente','Escape con fuga'),
(14,15,13,5,'2026-11-13','Pendiente','Cambio de amortiguadores traseros'),
(15,7,6,13,'2026-11-14','Pendiente','Cuatro llantas nuevas');

-- El costo de cada orden parte del precio base del servicio.
UPDATE orden_servicio o
INNER JOIN tipo_servicio s ON s.id_tipo_servicio = o.id_tipo_servicio
SET o.costo = s.precio_base;

-- >>>>>>>>>> 03_seguridad.sql <<<<<<<<<<
-- ============================================================
--  03_seguridad.sql : perfiles, roles, usuarios y privilegios
--  (los GRANT EXECUTE sobre procedimientos y funciones están al
--   final de 04_procedural.sql, porque esas rutinas aún no existen)
-- ============================================================
USE taller_mecanico;

-- 3.1 Perfiles de usuario
--   Administrador : todo el sistema, incluida la bitácora.
--   Operador      : atiende clientes, vehículos y órdenes; solo consulta
--                   empleados y servicios; no puede borrar nada.
--   Consulta      : solo ve las vistas de reportes (sin acceso a tablas).

-- 3.4 Roles (los permisos se otorgan al rol, no al usuario)
CREATE ROLE IF NOT EXISTS 'rol_admin', 'rol_operador', 'rol_consulta';

-- 3.3 Privilegios distintos por objeto
-- Administrador
GRANT ALL PRIVILEGES ON taller_mecanico.* TO 'rol_admin';

-- Operador: tablas
GRANT SELECT                 ON taller_mecanico.empleado       TO 'rol_operador';
GRANT SELECT                 ON taller_mecanico.tipo_servicio  TO 'rol_operador';
GRANT SELECT, INSERT, UPDATE ON taller_mecanico.cliente        TO 'rol_operador';
GRANT SELECT, INSERT, UPDATE ON taller_mecanico.vehiculo       TO 'rol_operador';
GRANT SELECT, INSERT, UPDATE ON taller_mecanico.orden_servicio TO 'rol_operador';
GRANT SELECT, UPDATE         ON taller_mecanico.herramienta    TO 'rol_operador';
-- Operador: vistas
GRANT SELECT ON taller_mecanico.v_ordenes_detalle    TO 'rol_operador';
GRANT SELECT ON taller_mecanico.v_vehiculos_cliente  TO 'rol_operador';
GRANT SELECT ON taller_mecanico.v_herramientas_uso   TO 'rol_operador';

-- Consulta: únicamente vistas
GRANT SELECT ON taller_mecanico.v_ordenes_detalle    TO 'rol_consulta';
GRANT SELECT ON taller_mecanico.v_vehiculos_cliente  TO 'rol_consulta';
GRANT SELECT ON taller_mecanico.v_herramientas_uso   TO 'rol_consulta';

-- GRANT y REVOKE: ejemplo de privilegio que se concede y luego se retira
GRANT DELETE ON taller_mecanico.cliente TO 'rol_operador';
REVOKE DELETE ON taller_mecanico.cliente FROM 'rol_operador';

-- 3.2 Creación de usuarios (nadie se conecta como root en la app)
CREATE USER IF NOT EXISTS 'taller_admin'@'localhost'    IDENTIFIED BY 'Admin123!';
CREATE USER IF NOT EXISTS 'taller_operador'@'localhost' IDENTIFIED BY 'Oper123!';
CREATE USER IF NOT EXISTS 'taller_consulta'@'localhost' IDENTIFIED BY 'Cons123!';

GRANT 'rol_admin'    TO 'taller_admin'@'localhost';
GRANT 'rol_operador' TO 'taller_operador'@'localhost';
GRANT 'rol_consulta' TO 'taller_consulta'@'localhost';
SET DEFAULT ROLE ALL TO 'taller_admin'@'localhost',
                        'taller_operador'@'localhost',
                        'taller_consulta'@'localhost';
FLUSH PRIVILEGES;

-- Verificación
SHOW GRANTS FOR 'taller_operador'@'localhost' USING 'rol_operador';

-- >>>>>>>>>> 04_procedural.sql <<<<<<<<<<
-- ============================================================
--  04_procedural.sql : funciones, procedimientos, triggers y
--                      privilegios de ejecución
-- ============================================================
USE taller_mecanico;
DELIMITER $$

-- ---------- 5.2 FUNCIONES ----------
CREATE FUNCTION fn_costo_con_iva(p_precio DECIMAL(10,2)) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
  RETURN ROUND(p_precio * 1.16, 2);
END$$

CREATE FUNCTION fn_antiguedad_anios(p_fecha DATE) RETURNS INT
DETERMINISTIC
BEGIN
  RETURN TIMESTAMPDIFF(YEAR, p_fecha, CURDATE());
END$$

CREATE FUNCTION fn_ordenes_cliente(p_id_cliente INT) RETURNS INT
READS SQL DATA
BEGIN
  DECLARE v_total INT;
  SELECT COUNT(*) INTO v_total
  FROM orden_servicio o
  INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo
  WHERE v.id_cliente = p_id_cliente;
  RETURN v_total;
END$$

-- ---------- 5.1 PROCEDIMIENTOS ----------
-- 1) Registrar orden (parámetro OUT + manejo de errores con HANDLER)
CREATE PROCEDURE sp_registrar_orden(
  IN  p_id_vehiculo      INT,
  IN  p_id_tipo_servicio INT,
  IN  p_id_empleado      INT,
  IN  p_id_herramienta   INT,
  IN  p_fecha            DATE,
  IN  p_observaciones    VARCHAR(255),
  OUT p_id_orden         INT)
BEGIN
  DECLARE v_estado VARCHAR(20);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  IF p_id_herramienta IS NOT NULL THEN
    SELECT estado INTO v_estado FROM herramienta WHERE id_herramienta = p_id_herramienta;
    IF v_estado = 'Mantenimiento' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La herramienta seleccionada está en mantenimiento.';
    END IF;
  END IF;
  INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, id_herramienta, fecha_ingreso, observaciones)
  VALUES (p_id_vehiculo, p_id_tipo_servicio, p_id_empleado, p_id_herramienta, p_fecha, p_observaciones);
  SET p_id_orden = LAST_INSERT_ID();
  COMMIT;
END$$

-- 2) Cambiar estado de una orden (valida existencia y flujo)
CREATE PROCEDURE sp_cambiar_estado_orden(IN p_id_orden INT, IN p_estado VARCHAR(20))
BEGIN
  DECLARE v_actual VARCHAR(20);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  SELECT estado INTO v_actual FROM orden_servicio WHERE id_orden = p_id_orden;
  IF v_actual IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La orden indicada no existe.';
  END IF;
  IF v_actual = 'Entregado' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Una orden entregada ya no se puede modificar.';
  END IF;
  UPDATE orden_servicio SET estado = p_estado WHERE id_orden = p_id_orden;
  COMMIT;
END$$

-- 3) Total gastado por un cliente (parámetro de salida)
CREATE PROCEDURE sp_total_gastado_cliente(IN p_id_cliente INT, OUT p_total DECIMAL(12,2))
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cliente WHERE id_cliente = p_id_cliente) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El cliente indicado no existe.';
  END IF;
  SELECT IFNULL(SUM(o.costo), 0) INTO p_total
  FROM orden_servicio o
  INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo
  WHERE v.id_cliente = p_id_cliente;
END$$

-- 4) Reporte con GROUP BY, HAVING, agregados, fecha, cadena, CAST y ORDER BY
CREATE PROCEDURE sp_reporte_servicios(IN p_desde DATE, IN p_hasta DATE, IN p_min_ordenes INT)
BEGIN
  SELECT DATE_FORMAT(o.fecha_ingreso, '%Y-%m')      AS mes,
         UPPER(s.nombre)                            AS servicio,
         COUNT(*)                                   AS total_ordenes,
         SUM(o.costo)                               AS ingresos,
         CAST(AVG(o.costo) AS DECIMAL(10,2))        AS costo_promedio,
         CONCAT('$', FORMAT(SUM(o.costo), 2))       AS ingresos_texto
  FROM orden_servicio o
  INNER JOIN tipo_servicio s ON s.id_tipo_servicio = o.id_tipo_servicio
  WHERE o.fecha_ingreso BETWEEN p_desde AND p_hasta
  GROUP BY mes, servicio
  HAVING COUNT(*) >= p_min_ordenes
  ORDER BY mes, ingresos DESC;
END$$

-- 5) Órdenes por estado (cadena vacía = todas)
CREATE PROCEDURE sp_ordenes_por_estado(IN p_estado VARCHAR(20))
BEGIN
  SELECT id_orden, fecha_ingreso, estado, costo, placa, vehiculo, cliente, servicio, responsable, herramienta
  FROM v_ordenes_detalle
  WHERE p_estado = '' OR estado = p_estado
  ORDER BY fecha_ingreso DESC, id_orden DESC;
END$$

-- 6) Alta de cliente con su primer vehículo: dos tablas en una transacción
CREATE PROCEDURE sp_alta_cliente_vehiculo(
  IN  p_nombre    VARCHAR(60),  IN p_apellidos VARCHAR(80), IN p_telefono VARCHAR(20),
  IN  p_email     VARCHAR(100), IN p_direccion VARCHAR(150),
  IN  p_placa     VARCHAR(12),  IN p_marca VARCHAR(40), IN p_modelo VARCHAR(40),
  IN  p_anio      INT,          IN p_color VARCHAR(30),
  OUT p_id_cliente INT)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  INSERT INTO cliente (nombre, apellidos, telefono, email, direccion)
  VALUES (p_nombre, p_apellidos, p_telefono, p_email, p_direccion);
  SET p_id_cliente = LAST_INSERT_ID();
  INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio, color)
  VALUES (p_id_cliente, p_placa, p_marca, p_modelo, p_anio, p_color);
  COMMIT;
END$$

-- ---------- 5.3 TRIGGERS ----------
-- 1) Validación de reglas de negocio + costo por defecto
CREATE TRIGGER trg_orden_bi BEFORE INSERT ON orden_servicio
FOR EACH ROW
BEGIN
  IF NEW.fecha_ingreso > CURDATE() THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La fecha de ingreso no puede ser futura.';
  END IF;
  IF NEW.costo = 0 THEN
    SET NEW.costo = IFNULL((SELECT precio_base FROM tipo_servicio
                            WHERE id_tipo_servicio = NEW.id_tipo_servicio), 0);
  END IF;
END$$

-- 2) Bitácora de cambios de estado
CREATE TRIGGER trg_orden_au_bitacora AFTER UPDATE ON orden_servicio
FOR EACH ROW
BEGIN
  IF NOT (OLD.estado <=> NEW.estado) THEN
    INSERT INTO bitacora_orden (id_orden, estado_anterior, estado_nuevo, usuario)
    VALUES (NEW.id_orden, OLD.estado, NEW.estado, USER());
  END IF;
END$$

-- 3) Inventario de herramientas: descuenta al iniciar, regresa al terminar
CREATE TRIGGER trg_orden_au_inventario AFTER UPDATE ON orden_servicio
FOR EACH ROW
BEGIN
  IF NEW.id_herramienta IS NOT NULL THEN
    IF OLD.estado <> 'En proceso' AND NEW.estado = 'En proceso' THEN
      UPDATE herramienta SET cantidad_disponible = cantidad_disponible - 1
      WHERE id_herramienta = NEW.id_herramienta;      -- el CHECK impide quedar en negativo
    ELSEIF OLD.estado = 'En proceso' AND NEW.estado IN ('Terminado', 'Entregado') THEN
      UPDATE herramienta SET cantidad_disponible = cantidad_disponible + 1
      WHERE id_herramienta = NEW.id_herramienta;
    END IF;
  END IF;
END$$

DELIMITER ;

-- ---------- Privilegios sobre rutinas (3.3) ----------
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_registrar_orden       TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_cambiar_estado_orden  TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_total_gastado_cliente TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_alta_cliente_vehiculo TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_reporte_servicios     TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_ordenes_por_estado    TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON FUNCTION  taller_mecanico.fn_costo_con_iva         TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON FUNCTION  taller_mecanico.fn_antiguedad_anios      TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON FUNCTION  taller_mecanico.fn_ordenes_cliente       TO 'rol_operador', 'rol_consulta';

-- Prueba sesiones (Sesion A original)
USE taller_mecanico;
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT precio_base FROM tipo_servicio WHERE id_tipo_servicio = 1;
