# Proyecto Final - Taller de Base de Datos: Taller mecánico

Aplicación de escritorio en C# (Windows Forms, .NET 8) conectada a MySQL 8 con ADO.NET (MySql.Data). Sin ORM: todo el SQL está escrito a mano y parametrizado.

## Estructura
- `/sql`  01_esquema.sql, 02_datos.sql, 03_seguridad.sql, 04_procedural.sql, 05_consultas.sql, 06_concurrencia.sql
- `/app`  solución de Visual Studio (`TallerApp.sln`)
- `/docs` reporte en PDF, diagrama E-R (PNG y SVG)

## Cómo crear la base de datos
1. Instala MySQL 8 y abre MySQL Workbench con un usuario administrador (por ejemplo root; solo para crear la BD).
2. Ejecuta los scripts **en este orden**: `01_esquema.sql`, `02_datos.sql`, `03_seguridad.sql`, `04_procedural.sql`.
   (`05_consultas.sql` y `06_concurrencia.sql` son de consulta y de demostración.)
3. Se crean estos usuarios de BD (cambia las contraseñas si lo deseas):

| Perfil        | Usuario BD        | Contraseña |
|---------------|-------------------|------------|
| Administrador | taller_admin      | Admin123!  |
| Operador      | taller_operador   | Oper123!   |
| Consulta      | taller_consulta   | Cons123!   |

## Cómo ejecutar la aplicación
1. Abre `app/TallerApp.sln` en Visual Studio 2022 (carga de trabajo "Desarrollo de escritorio con .NET").
2. Restaura los paquetes NuGet (MySql.Data se descarga solo) y compila.
3. Revisa `app/TallerApp/appsettings.json`: la cadena de conexión se llama `taller` (servidor, puerto y base). El usuario lo elige el perfil en el login.
4. Ejecuta (F5), elige el perfil e ingresa su contraseña.

## Guion para la exposición (15 minutos)
1. **Dos perfiles:** entra como Administrador (ve Catálogos, Operaciones, Reportes y la bitácora) y luego como Consulta (solo Reportes).
2. **Error de permisos:** entra como Operador, abre Catálogos > Clientes e intenta Eliminar: aparece el mensaje de permisos (error 1142).
   También puedes intentar editar un empleado.
3. **Transacción con rollback:** Operaciones > Alta cliente + vehículo; captura una placa existente (SON-101-A). La app avisa del ROLLBACK y el cliente no aparece en Clientes.
4. **Trigger en acción:** Operaciones > Cambiar estado: pasa una orden a "En proceso" y revisa, como Administrador, Reportes > Bitácora. La herramienta descuenta una pieza.
   Para ver el rollback del trigger: pon en 0 las piezas de una herramienta (Catálogos > Herramientas) y pasa a "En proceso" una orden que la use.
5. **Concurrencia:** muestra en Workbench, con dos pestañas, `06_concurrencia.sql` (lectura sucia, no repetible y bloqueo con SERIALIZABLE).

## Notas
- El punto de entrada (`Main`) está en `app/TallerApp/Program.cs`.
- Las fotos que se suben desde los formularios se copian a la carpeta `Fotos` junto al ejecutable.
- Sube el código a un repositorio Git con commits de todos los integrantes (el archivo `.gitignore` ya excluye bin/obj).
