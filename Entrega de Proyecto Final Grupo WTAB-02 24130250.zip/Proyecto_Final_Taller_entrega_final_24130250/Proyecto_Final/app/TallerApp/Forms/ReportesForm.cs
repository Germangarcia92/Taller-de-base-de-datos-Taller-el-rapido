using System.Data;
using MySql.Data.MySqlClient;
using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Reportes: vistas, joins, subconsultas, UNION, agrupamientos y procedimientos almacenados.</summary>
public class ReportesForm : Form
{
    private class Reporte
    {
        public string Nombre, Sql, Parametros = "";   // "", "fechas" o "estado"
        public bool EsProcedimiento;
        public string[] Perfiles;                     // null = todos los perfiles
        public override string ToString() => Nombre;
    }

    private static readonly Reporte[] Todos =
    {
        new() { Nombre = "Vista: órdenes con detalle (INNER/LEFT JOIN)", Sql = "SELECT * FROM v_ordenes_detalle ORDER BY id_orden DESC" },
        new() { Nombre = "Vista: vehículos y sus clientes", Sql = "SELECT * FROM v_vehiculos_cliente ORDER BY id_vehiculo" },
        new() { Nombre = "Vista: herramientas y órdenes en proceso (LEFT JOIN + GROUP BY)", Sql = "SELECT * FROM v_herramientas_uso ORDER BY ordenes_en_proceso DESC, nombre" },
        new() { Nombre = "SP: servicios por mes (GROUP BY, HAVING, CAST)", Sql = "sp_reporte_servicios", EsProcedimiento = true, Parametros = "fechas" },
        new() { Nombre = "SP: órdenes por estado", Sql = "sp_ordenes_por_estado", EsProcedimiento = true, Parametros = "estado" },
        new()
        {
            Nombre = "LEFT JOIN: empleados y su número de órdenes",
            Perfiles = new[] { "Administrador", "Operador" },
            Sql = "SELECT CONCAT(e.nombre,' ',e.apellidos) AS responsable, e.puesto, COUNT(o.id_orden) AS ordenes " +
                  "FROM empleado e LEFT JOIN orden_servicio o ON o.id_empleado = e.id_empleado " +
                  "GROUP BY e.id_empleado, e.nombre, e.apellidos, e.puesto ORDER BY ordenes DESC, responsable"
        },
        new()
        {
            Nombre = "Subconsulta en WHERE: servicios sobre el precio promedio",
            Perfiles = new[] { "Administrador", "Operador" },
            Sql = "SELECT nombre, precio_base, fn_costo_con_iva(precio_base) AS precio_con_iva FROM tipo_servicio " +
                  "WHERE precio_base > (SELECT AVG(precio_base) FROM tipo_servicio) ORDER BY precio_base DESC"
        },
        new()
        {
            Nombre = "Subconsulta correlacionada: última visita por cliente",
            Perfiles = new[] { "Administrador", "Operador" },
            Sql = "SELECT CONCAT(c.nombre,' ',c.apellidos) AS cliente, " +
                  "(SELECT MAX(o.fecha_ingreso) FROM orden_servicio o INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo " +
                  " WHERE v.id_cliente = c.id_cliente) AS ultima_visita, fn_ordenes_cliente(c.id_cliente) AS ordenes " +
                  "FROM cliente c ORDER BY ultima_visita DESC"
        },
        new()
        {
            Nombre = "Subconsulta en FROM: empleados sobre el promedio de órdenes",
            Perfiles = new[] { "Administrador", "Operador" },
            Sql = "SELECT CONCAT(e.nombre,' ',e.apellidos) AS responsable, t.total " +
                  "FROM empleado e INNER JOIN (SELECT id_empleado, COUNT(*) AS total FROM orden_servicio GROUP BY id_empleado) t " +
                  "ON t.id_empleado = e.id_empleado " +
                  "WHERE t.total > (SELECT AVG(x.total) FROM (SELECT COUNT(*) AS total FROM orden_servicio GROUP BY id_empleado) x) " +
                  "ORDER BY t.total DESC"
        },
        new()
        {
            Nombre = "UNION: directorio de clientes y empleados",
            Perfiles = new[] { "Administrador", "Operador" },
            Sql = "SELECT CONCAT(nombre,' ',apellidos) AS nombre, telefono, 'Cliente' AS tipo FROM cliente " +
                  "UNION SELECT CONCAT(nombre,' ',apellidos), telefono, 'Empleado' FROM empleado ORDER BY tipo, nombre"
        },
        new()
        {
            Nombre = "Bitácora de cambios de estado (solo Administrador)",
            Perfiles = new[] { "Administrador" },
            Sql = "SELECT id_bitacora, id_orden, estado_anterior, estado_nuevo, usuario, fecha " +
                  "FROM bitacora_orden ORDER BY id_bitacora DESC"
        }
    };

    private readonly ComboBox _reporte = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 430 };
    private readonly DateTimePicker _desde = new() { Format = DateTimePickerFormat.Short, Width = 110, Value = new DateTime(2026, 10, 1) };
    private readonly DateTimePicker _hasta = new() { Format = DateTimePickerFormat.Short, Width = 110, Value = new DateTime(2026, 12, 31) };
    private readonly NumericUpDown _minimo = new() { Width = 50, Minimum = 1, Maximum = 99, Value = 1 };
    private readonly ComboBox _estado = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 120 };
    private readonly Label _lDesde = new() { Text = "Desde:", AutoSize = true, Margin = new Padding(8, 8, 2, 0) };
    private readonly Label _lHasta = new() { Text = "Hasta:", AutoSize = true, Margin = new Padding(8, 8, 2, 0) };
    private readonly Label _lMin = new() { Text = "Mín. órdenes:", AutoSize = true, Margin = new Padding(8, 8, 2, 0) };
    private readonly Label _lEstado = new() { Text = "Estado:", AutoSize = true, Margin = new Padding(8, 8, 2, 0) };
    private readonly DataGridView _grid = new()
    {
        Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, BackgroundColor = Color.White,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
    };

    public ReportesForm()
    {
        Text = "Reportes";
        Size = new Size(1100, 620);
        StartPosition = FormStartPosition.CenterParent;

        // Solo se ofrecen los reportes permitidos para el perfil.
        foreach (Reporte r in Todos)
            if (r.Perfiles == null || r.Perfiles.Contains(Db.Perfil)) _reporte.Items.Add(r);
        _reporte.SelectedIndexChanged += (s, a) => MostrarParametros();
        _estado.Items.AddRange(new object[] { "", "Pendiente", "En proceso", "Terminado", "Entregado" });
        _estado.SelectedIndex = 0;

        var ejecutar = new Button { Text = "Ejecutar", Width = 90, Height = 28 };
        Ui.EstilizarBoton(ejecutar, Ui.Primario, Color.White);
        ejecutar.Click += (s, a) => Ejecutar();

        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 78, Padding = new Padding(8) };
        barra.Controls.AddRange(new Control[] { _reporte, _lDesde, _desde, _lHasta, _hasta, _lMin, _minimo, _lEstado, _estado, ejecutar });

        _grid.DataBindingComplete += (s, a) =>
        {
            foreach (DataGridViewColumn col in _grid.Columns)
                if (col.ValueType == typeof(DateTime)) col.DefaultCellStyle.Format = "yyyy-MM-dd";
        };
        Controls.Add(_grid);
        Controls.Add(barra);

        _reporte.SelectedIndex = 0;
    }

    private void MostrarParametros()
    {
        var r = (Reporte)_reporte.SelectedItem;
        bool fechas = r.Parametros == "fechas", estado = r.Parametros == "estado";
        _lDesde.Visible = _desde.Visible = _lHasta.Visible = _hasta.Visible = _lMin.Visible = _minimo.Visible = fechas;
        _lEstado.Visible = _estado.Visible = estado;
    }

    private void Ejecutar()
    {
        var r = (Reporte)_reporte.SelectedItem;
        try
        {
            MySqlParameter[] ps = Array.Empty<MySqlParameter>();
            if (r.Parametros == "fechas")
                ps = new[]
                {
                    new MySqlParameter("p_desde", MySqlDbType.Date) { Value = _desde.Value.Date },
                    new MySqlParameter("p_hasta", MySqlDbType.Date) { Value = _hasta.Value.Date },
                    new MySqlParameter("p_min_ordenes", MySqlDbType.Int32) { Value = (int)_minimo.Value }
                };
            else if (r.Parametros == "estado")
                ps = new[] { new MySqlParameter("p_estado", MySqlDbType.VarChar) { Value = _estado.Text } };

            _grid.DataSource = ReporteDao.Ejecutar(r.Sql, r.EsProcedimiento, ps);
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));
        }
    }
}
