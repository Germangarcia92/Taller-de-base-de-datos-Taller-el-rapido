using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Operaciones de negocio: transacción con rollback, procedimientos con parámetro OUT y triggers.</summary>
public class OperacionesForm : Form
{
    private static readonly string CmbOrdenes =
        "SELECT o.id_orden AS id, CONCAT('#', o.id_orden, ' · ', v.placa, ' · ', o.estado) AS texto " +
        "FROM orden_servicio o INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo ORDER BY o.id_orden DESC";
    private const string CmbClientes =
        "SELECT id_cliente AS id, CONCAT(nombre,' ',apellidos) AS texto FROM cliente ORDER BY texto";

    public OperacionesForm()
    {
        Text = "Operaciones";
        Size = new Size(620, 470);
        StartPosition = FormStartPosition.CenterParent;
        var tabs = new TabControl { Dock = DockStyle.Fill };
        try
        {
            tabs.TabPages.Add(TabTransaccion());
            tabs.TabPages.Add(TabNuevaOrden());
            tabs.TabPages.Add(TabEstado());
            tabs.TabPages.Add(TabTotal());
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));
        }
        Controls.Add(tabs);
    }

    // 1) Transacción manejada desde C# (MySqlTransaction): COMMIT o ROLLBACK
    private TabPage TabTransaccion()
    {
        var tab = new TabPage("Alta cliente + vehículo");
        var nombre = new TextBox { Left = 190, Top = 15, Width = 250 };
        var apellidos = new TextBox { Left = 190, Top = 49, Width = 250 };
        var telefono = new TextBox { Left = 190, Top = 83, Width = 250 };
        var placa = new TextBox { Left = 190, Top = 117, Width = 250 };
        var marca = new TextBox { Left = 190, Top = 151, Width = 250 };
        var modelo = new TextBox { Left = 190, Top = 185, Width = 250 };
        var anio = new NumericUpDown { Left = 190, Top = 219, Width = 100, Minimum = 1900, Maximum = 2200, Value = 2020 };
        var boton = new Button { Text = "Guardar (transacción)", Left = 190, Top = 260, Width = 170, Height = 30 };
        Ui.EstilizarBoton(boton, Ui.Exito, Color.White);
        var nota = new Label
        {
            Left = 15, Top = 305, Width = 560, Height = 60, ForeColor = Color.DimGray,
            Text = "Inserta en cliente y vehiculo dentro de una sola transacción. Para ver el ROLLBACK usa una placa que ya exista (por ejemplo SON-101-A): el cliente tampoco se guardará."
        };
        tab.Controls.AddRange(new Control[]
        {
            Ui.Etiqueta("Nombre *", 15, 15), nombre, Ui.Etiqueta("Apellidos *", 15, 49), apellidos,
            Ui.Etiqueta("Teléfono *", 15, 83), telefono, Ui.Etiqueta("Placa *", 15, 117), placa,
            Ui.Etiqueta("Marca *", 15, 151), marca, Ui.Etiqueta("Modelo *", 15, 185), modelo,
            Ui.Etiqueta("Año *", 15, 219), anio, boton, nota
        });
        boton.Click += (s, a) =>
        {
            try
            {
                foreach (var t in new[] { nombre, apellidos, telefono, placa, marca, modelo })
                    if (t.Text.Trim() == "") throw new ValidacionException("Todos los campos son obligatorios.");
                int id = OperacionesDao.AltaClienteConVehiculo(nombre.Text.Trim(), apellidos.Text.Trim(), telefono.Text.Trim(),
                    placa.Text.Trim(), marca.Text.Trim(), modelo.Text.Trim(), (int)anio.Value);
                Ui.Info("COMMIT: se guardaron el cliente (id " + id + ") y su vehículo.");
            }
            catch (ValidacionException ex)
            {
                Ui.Error(ex.Message);
            }
            catch (Exception ex)
            {
                Ui.Error("ROLLBACK: la operación completa se deshizo, el cliente tampoco se guardó.\n\nMotivo: " + Errores.Mensaje(ex));
            }
        };
        return tab;
    }

    // 2) Procedimiento con parámetro de salida
    private TabPage TabNuevaOrden()
    {
        var tab = new TabPage("Nueva orden (SP)");
        var vehiculo = new ComboBox { Left = 190, Top = 15, Width = 300 };
        var servicio = new ComboBox { Left = 190, Top = 49, Width = 300 };
        var empleado = new ComboBox { Left = 190, Top = 83, Width = 300 };
        var herramienta = new ComboBox { Left = 190, Top = 117, Width = 300 };
        var fecha = new DateTimePicker { Left = 190, Top = 151, Width = 130, Format = DateTimePickerFormat.Short };
        var obs = new TextBox { Left = 190, Top = 185, Width = 300 };
        var boton = new Button { Text = "Registrar orden", Left = 190, Top = 225, Width = 150, Height = 30 };
        Ui.EstilizarBoton(boton, Ui.Exito, Color.White);
        Ui.LlenarCombo(vehiculo, Entidades.CmbVehiculos);
        Ui.LlenarCombo(servicio, Entidades.CmbServicios);
        Ui.LlenarCombo(empleado, Entidades.CmbEmpleados);
        Ui.LlenarCombo(herramienta, Entidades.CmbHerramientas);
        tab.Controls.AddRange(new Control[]
        {
            Ui.Etiqueta("Vehículo *", 15, 15), vehiculo, Ui.Etiqueta("Servicio *", 15, 49), servicio,
            Ui.Etiqueta("Responsable *", 15, 83), empleado, Ui.Etiqueta("Herramienta", 15, 117), herramienta,
            Ui.Etiqueta("Fecha de ingreso *", 15, 151), fecha, Ui.Etiqueta("Observaciones", 15, 185), obs, boton
        });
        boton.Click += (s, a) =>
        {
            try
            {
                int? v = Ui.IdSeleccionado(vehiculo), sv = Ui.IdSeleccionado(servicio), em = Ui.IdSeleccionado(empleado);
                if (v == null || sv == null || em == null) throw new ValidacionException("Vehículo, servicio y responsable son obligatorios.");
                int id = OperacionesDao.RegistrarOrden(v.Value, sv.Value, em.Value, Ui.IdSeleccionado(herramienta),
                    fecha.Value, obs.Text.Trim() == "" ? null : obs.Text.Trim());
                Ui.Info("Orden registrada con el id " + id + " (parámetro de salida del procedimiento).");
            }
            catch (Exception ex)
            {
                Ui.Error(Errores.Mensaje(ex));
            }
        };
        return tab;
    }

    // 3) Cambio de estado: dispara los triggers de bitácora e inventario
    private TabPage TabEstado()
    {
        var tab = new TabPage("Cambiar estado (triggers)");
        var orden = new ComboBox { Left = 190, Top = 15, Width = 330 };
        var estado = new ComboBox { Left = 190, Top = 49, Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
        estado.Items.AddRange(new object[] { "Pendiente", "En proceso", "Terminado", "Entregado" });
        estado.SelectedIndex = 1;
        var boton = new Button { Text = "Cambiar estado", Left = 190, Top = 90, Width = 150, Height = 30 };
        Ui.EstilizarBoton(boton, Ui.Advertencia, Color.White);
        var nota = new Label
        {
            Left = 15, Top = 140, Width = 560, Height = 80, ForeColor = Color.DimGray,
            Text = "Llama a sp_cambiar_estado_orden. Los triggers registran el cambio en la bitácora y descuentan o devuelven la herramienta. " +
                   "Si la herramienta no tiene existencias, el CHECK falla y se hace rollback."
        };
        Ui.LlenarCombo(orden, CmbOrdenes);
        tab.Controls.AddRange(new Control[] { Ui.Etiqueta("Orden *", 15, 15), orden, Ui.Etiqueta("Nuevo estado *", 15, 49), estado, boton, nota });
        boton.Click += (s, a) =>
        {
            try
            {
                int? id = Ui.IdSeleccionado(orden);
                if (id == null) throw new ValidacionException("Selecciona una orden.");
                OperacionesDao.CambiarEstado(id.Value, estado.Text);
                Ui.Info("Estado actualizado. Los triggers registraron la bitácora y ajustaron el inventario.");
                Ui.LlenarCombo(orden, CmbOrdenes);
            }
            catch (Exception ex)
            {
                Ui.Error(Errores.Mensaje(ex));
            }
        };
        return tab;
    }

    // 4) Parámetro OUT y función definida por el usuario
    private TabPage TabTotal()
    {
        var tab = new TabPage("Total por cliente");
        var cliente = new ComboBox { Left = 190, Top = 15, Width = 330 };
        var boton = new Button { Text = "Calcular", Left = 190, Top = 55, Width = 120, Height = 30 };
        Ui.EstilizarBoton(boton, Ui.Primario, Color.White);
        var resultado = new Label { Left = 15, Top = 110, Width = 560, Height = 60, Font = new Font("Segoe UI", 12, FontStyle.Bold) };
        Ui.LlenarCombo(cliente, CmbClientes);
        tab.Controls.AddRange(new Control[] { Ui.Etiqueta("Cliente *", 15, 15), cliente, boton, resultado });
        boton.Click += (s, a) =>
        {
            try
            {
                int? id = Ui.IdSeleccionado(cliente);
                if (id == null) throw new ValidacionException("Selecciona un cliente.");
                var (total, ordenes) = OperacionesDao.TotalCliente(id.Value);
                resultado.Text = "Órdenes: " + ordenes + "    Total gastado: " + total.ToString("C2");
            }
            catch (Exception ex)
            {
                Ui.Error(Errores.Mensaje(ex));
            }
        };
        return tab;
    }
}
