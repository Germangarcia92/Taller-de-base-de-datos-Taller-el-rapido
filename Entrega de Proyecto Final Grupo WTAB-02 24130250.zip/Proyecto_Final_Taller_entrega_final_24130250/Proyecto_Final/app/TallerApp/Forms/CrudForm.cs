using System.Data;
using System.Globalization;
using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Listado con filtros (texto y rango) y alta / modificación / baja de una tabla.</summary>
public class CrudForm : Form
{
    private readonly Entidad _e;
    private readonly DataGridView _grid = new()
    {
        Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, MultiSelect = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells, BackgroundColor = Color.White
    };
    private readonly TextBox _texto = new() { Width = 170 };
    private readonly TextBox _desde = new() { Width = 90 };
    private readonly TextBox _hasta = new() { Width = 90 };

    public CrudForm(Entidad e)
    {
        _e = e;
        Text = e.Titulo;
        Size = new Size(1100, 620);
        StartPosition = FormStartPosition.CenterParent;

        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 78, Padding = new Padding(8), WrapContents = true };
        barra.Controls.Add(new Label { Text = e.TextoEtiqueta + ":", AutoSize = true, Margin = new Padding(3, 8, 3, 0) });
        barra.Controls.Add(_texto);
        if (e.RangoCol != null)
        {
            string ayuda = e.RangoFecha ? " (AAAA-MM-DD)" : "";
            barra.Controls.Add(new Label { Text = e.RangoEtiqueta + ayuda + ":", AutoSize = true, Margin = new Padding(12, 8, 3, 0) });
            barra.Controls.Add(_desde);
            barra.Controls.Add(new Label { Text = "y", AutoSize = true, Margin = new Padding(3, 8, 3, 0) });
            barra.Controls.Add(_hasta);
        }
        barra.Controls.Add(Boton("Buscar", (s, a) => Buscar(), Ui.Primario));
        barra.Controls.Add(Boton("Limpiar", (s, a) => { _texto.Clear(); _desde.Clear(); _hasta.Clear(); Buscar(); }, Ui.Neutro, Ui.Primario));
        barra.Controls.Add(Boton("Nuevo", (s, a) => AbrirEdicion(null), Ui.Exito));
        barra.Controls.Add(Boton("Editar", (s, a) => Modificar(), Ui.Advertencia));
        barra.Controls.Add(Boton("Eliminar", (s, a) => Eliminar(), Ui.Peligro));

        _grid.DataBindingComplete += (s, a) =>
        {
            foreach (DataGridViewColumn col in _grid.Columns)
                if (col.ValueType == typeof(DateTime)) col.DefaultCellStyle.Format = "yyyy-MM-dd";
        };
        _grid.CellDoubleClick += (s, a) => { if (a.RowIndex >= 0) Modificar(); };

        Controls.Add(_grid);
        Controls.Add(barra);
        Load += (s, a) => Buscar();
    }

    private static Button Boton(string texto, EventHandler accion, Color fondo, Color textoColor = default)
    {
        var b = new Button { Text = texto, Width = 80, Height = 28 };
        Ui.EstilizarBoton(b, fondo, textoColor == default ? Color.White : textoColor);
        b.Click += accion;
        return b;
    }

    private int? IdSeleccionado() =>
        _grid.CurrentRow == null ? null : Convert.ToInt32(_grid.CurrentRow.Cells[0].Value);

    private object LeerRango(string s)
    {
        s = s.Trim();
        if (s == "") return null;
        if (_e.RangoFecha)
        {
            if (DateTime.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var f)) return f;
            throw new ValidacionException("Escribe las fechas como AAAA-MM-DD.");
        }
        if (decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out var n)) return n;
        throw new ValidacionException("El rango debe ser numérico.");
    }

    private void Buscar()
    {
        try
        {
            object d = _e.RangoCol == null ? null : LeerRango(_desde.Text);
            object h = _e.RangoCol == null ? null : LeerRango(_hasta.Text);
            _grid.DataSource = CrudDao.Listar(_e, _texto.Text, d, h);
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));
        }
    }

    private void Modificar()
    {
        int? id = IdSeleccionado();
        if (id == null) { Ui.Info("Selecciona un registro."); return; }
        AbrirEdicion(id);
    }

    private void AbrirEdicion(int? id)
    {
        using var f = new EditForm(_e, id);
        if (f.ShowDialog(this) == DialogResult.OK) Buscar();
    }

    private void Eliminar()
    {
        int? id = IdSeleccionado();
        if (id == null) { Ui.Info("Selecciona un registro."); return; }
        if (!Ui.Confirmar("¿Eliminar el registro " + id + "?")) return;
        try
        {
            CrudDao.Eliminar(_e, id.Value);
            Buscar();
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));   // aquí aparece el error de permisos para un perfil restringido
        }
    }
}
