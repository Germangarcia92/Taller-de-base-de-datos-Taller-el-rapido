using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Menú principal: muestra u oculta opciones según el perfil.</summary>
public class MainForm : Form
{
    public bool CerrarSesion { get; private set; }

    public MainForm()
    {
        Text = "Taller El Rápido · Gestión del taller";
        WindowState = FormWindowState.Maximized;
        var menu = new MenuStrip();

        // Consulta no ve catálogos ni operaciones: solo reportes.
        if (!Db.EsConsulta)
        {
            var catalogos = new ToolStripMenuItem("Catálogos");
            foreach (Entidad entidad in Entidades.Todas)
            {
                Entidad e = entidad;
                catalogos.DropDownItems.Add(e.Titulo, null, (s, a) => Abrir(new CrudForm(e)));
            }
            menu.Items.Add(catalogos);
            menu.Items.Add(new ToolStripMenuItem("Operaciones", null, (s, a) => Abrir(new OperacionesForm())));
        }
        menu.Items.Add(new ToolStripMenuItem("Reportes", null, (s, a) => Abrir(new ReportesForm())));
        menu.Items.Add(new ToolStripMenuItem("Cerrar sesión", null, (s, a) => { CerrarSesion = true; Close(); }));
        menu.BackColor = Ui.Primario;
        menu.ForeColor = Color.White;
        menu.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        foreach (ToolStripMenuItem item in menu.Items)
        {
            item.BackColor = Ui.Primario;
            item.ForeColor = Color.White;
            item.Padding = new Padding(10, 5, 10, 5);
        }
        MainMenuStrip = menu;

        var bienvenida = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3,
            Padding = new Padding(28), BackColor = Color.FromArgb(245, 247, 250)
        };
        bienvenida.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        bienvenida.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        bienvenida.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var titulo = new Label
        {
            Dock = DockStyle.Fill, Text = "Taller El Rápido",
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 27, FontStyle.Bold), ForeColor = Ui.Primario
        };
        var perfil = new Label
        {
            Dock = DockStyle.Fill,
            Text = "Perfil: " + Db.Perfil + "   (usuario de BD: " + Db.Usuario + ")",
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 12, FontStyle.Bold), ForeColor = Color.FromArgb(70, 80, 95)
        };
        var fotos = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1,
            Padding = new Padding(8), BackColor = Color.White
        };
        fotos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        fotos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        fotos.Controls.Add(CrearFoto("taller.jpg", "Interior del taller"), 0, 0);
        fotos.Controls.Add(CrearFoto("herramientas.jpg", "Herramientas del taller"), 1, 0);

        bienvenida.Controls.Add(titulo, 0, 0);
        bienvenida.Controls.Add(perfil, 0, 1);
        bienvenida.Controls.Add(fotos, 0, 2);
        Controls.Add(bienvenida);
        Controls.Add(menu);
    }

    private static PictureBox CrearFoto(string archivo, string descripcion) =>
        new PictureBox
        {
            Dock = DockStyle.Fill, Margin = new Padding(12),
            SizeMode = PictureBoxSizeMode.Zoom, BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White, Image = CargarImagen(archivo),
            AccessibleDescription = descripcion
        };

    private static Image CargarImagen(string archivo)
    {
        string ruta = Path.Combine(AppContext.BaseDirectory, "Assets", archivo);
        using var stream = File.OpenRead(ruta);
        using var imagen = Image.FromStream(stream);
        return new Bitmap(imagen);
    }

    private void Abrir(Form f)
    {
        using (f) f.ShowDialog(this);
    }
}
