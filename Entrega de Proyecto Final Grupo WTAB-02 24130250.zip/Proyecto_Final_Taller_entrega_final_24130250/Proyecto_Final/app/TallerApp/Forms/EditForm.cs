using System.Globalization;
using System.Text.RegularExpressions;
using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Formulario de alta / edición generado a partir de los campos de la entidad, con validación previa.</summary>
public class EditForm : Form
{
    private readonly Entidad _e;
    private readonly int? _id;
    private readonly Dictionary<string, Control> _ctl = new();
    private readonly Dictionary<string, PictureBox> _fotos = new();

    public EditForm(Entidad e, int? id)
    {
        _e = e;
        _id = id;
        Text = (id == null ? "Nuevo · " : "Editar · ") + e.Titulo;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;

        var panel = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        int y = 15;
        try
        {
            foreach (Campo c in e.Campos)
            {
                panel.Controls.Add(Ui.Etiqueta(c.Etiqueta + (c.Requerido ? " *" : ""), 15, y, 160));
                Control ctl = Crear(c, panel, y);
                _ctl[c.Col] = ctl;
                panel.Controls.Add(ctl);
                y += c.Tipo == Tipo.Foto ? 140 : c.Tipo == Tipo.Area ? 70 : 34;
            }
            if (id != null) Cargar(CrudDao.Obtener(e, id.Value));
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));
        }

        var guardar = new Button { Text = "Guardar", Left = 170, Top = 10, Width = 100 };
        var cancelar = new Button { Text = "Cancelar", Left = 280, Top = 10, Width = 100, DialogResult = DialogResult.Cancel };
        Ui.EstilizarBoton(guardar, Ui.Exito, Color.White);
        Ui.EstilizarBoton(cancelar, Ui.Neutro, Ui.Primario);
        guardar.Click += Guardar;
        var pie = new Panel { Dock = DockStyle.Bottom, Height = 50 };
        pie.Controls.AddRange(new Control[] { guardar, cancelar });

        Controls.Add(panel);
        Controls.Add(pie);
        ClientSize = new Size(520, Math.Min(y + 70, 640));
        AcceptButton = guardar;
        CancelButton = cancelar;
    }

    private Control Crear(Campo c, Panel panel, int y)
    {
        switch (c.Tipo)
        {
            case Tipo.Area:
                return new TextBox { Left = 175, Top = y, Width = 310, Height = 56, Multiline = true, MaxLength = c.Max };
            case Tipo.Numero:
                return new TextBox { Left = 175, Top = y, Width = 150, Text = c.Defecto ?? "" };
            case Tipo.Fecha:
                return new DateTimePicker
                {
                    Left = 175, Top = y, Width = 150, Format = DateTimePickerFormat.Short,
                    ShowCheckBox = !c.Requerido, Value = DateTime.Today
                };
            case Tipo.Combo:
                var cb = new ComboBox { Left = 175, Top = y, Width = 310 };
                Ui.LlenarCombo(cb, c.ComboSql);
                return cb;
            case Tipo.Lista:
                var lista = new ComboBox { Left = 175, Top = y, Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
                lista.Items.AddRange(c.Opciones);
                lista.SelectedIndex = 0;
                return lista;
            case Tipo.Foto:
                var ruta = new TextBox { Left = 175, Top = y, Width = 220, ReadOnly = true };
                var examinar = new Button { Text = "Examinar...", Left = 402, Top = y - 1, Width = 85 };
                Ui.EstilizarBoton(examinar, Ui.Primario, Color.White);
                var imagen = new PictureBox
                {
                    Left = 175, Top = y + 32, Width = 100, Height = 100,
                    SizeMode = PictureBoxSizeMode.Zoom, BorderStyle = BorderStyle.FixedSingle
                };
                examinar.Click += (s, a) => ElegirFoto(ruta, imagen);
                panel.Controls.Add(examinar);
                panel.Controls.Add(imagen);
                _fotos[c.Col] = imagen;
                return ruta;
            default:
                return new TextBox { Left = 175, Top = y, Width = 310, MaxLength = c.Max };
        }
    }

    // -------------------------------------------------------------- Fotos
    private static string CarpetaFotos => Path.Combine(AppContext.BaseDirectory, "Fotos");

    private void ElegirFoto(TextBox ruta, PictureBox imagen)
    {
        using var dlg = new OpenFileDialog { Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.gif;*.bmp" };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        Directory.CreateDirectory(CarpetaFotos);
        string nombre = Guid.NewGuid().ToString("N") + Path.GetExtension(dlg.FileName).ToLowerInvariant();
        File.Copy(dlg.FileName, Path.Combine(CarpetaFotos, nombre));
        ruta.Text = nombre;
        MostrarFoto(imagen, nombre);
    }

    private static void MostrarFoto(PictureBox imagen, string nombre)
    {
        string archivo = Path.Combine(CarpetaFotos, nombre);
        imagen.Image = File.Exists(archivo) ? new Bitmap(new MemoryStream(File.ReadAllBytes(archivo))) : null;
    }

    // ---------------------------------------------------- Cargar / Leer
    private void Cargar(Dictionary<string, object> fila)
    {
        foreach (Campo c in _e.Campos)
        {
            object v = fila.TryGetValue(c.Col, out var x) ? x : null;
            Control ctl = _ctl[c.Col];
            switch (c.Tipo)
            {
                case Tipo.Fecha:
                    var dtp = (DateTimePicker)ctl;
                    if (v == null) dtp.Checked = false;
                    else { dtp.Checked = true; dtp.Value = Convert.ToDateTime(v); }
                    break;
                case Tipo.Combo:
                    if (v != null) ((ComboBox)ctl).SelectedValue = Convert.ToInt32(v);
                    break;
                case Tipo.Lista:
                    if (v != null) ((ComboBox)ctl).SelectedItem = v.ToString();
                    break;
                case Tipo.Foto:
                    ctl.Text = v?.ToString() ?? "";
                    if (v != null) MostrarFoto(_fotos[c.Col], v.ToString());
                    break;
                case Tipo.Numero:
                    ctl.Text = v == null ? "" : Convert.ToString(v, CultureInfo.InvariantCulture);
                    break;
                default:
                    ctl.Text = v?.ToString() ?? "";
                    break;
            }
        }
    }

    private object Leer(Campo c)
    {
        Control ctl = _ctl[c.Col];
        switch (c.Tipo)
        {
            case Tipo.Numero:
            {
                string s = ctl.Text.Trim();
                if (s == "")
                {
                    if (c.Requerido) throw new ValidacionException("\"" + c.Etiqueta + "\" es obligatorio.");
                    return null;
                }
                if (!decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out var d))
                    throw new ValidacionException("\"" + c.Etiqueta + "\" debe ser un número.");
                if (c.Entero)
                {
                    if (d != Math.Truncate(d)) throw new ValidacionException("\"" + c.Etiqueta + "\" debe ser un número entero.");
                    return (int)d;
                }
                return d;
            }
            case Tipo.Fecha:
            {
                var dtp = (DateTimePicker)ctl;
                if (dtp.ShowCheckBox && !dtp.Checked) return null;
                return dtp.Value.Date;
            }
            case Tipo.Combo:
            {
                int? id = Ui.IdSeleccionado((ComboBox)ctl);
                if (id == null && c.Requerido) throw new ValidacionException("Selecciona un valor en \"" + c.Etiqueta + "\".");
                return id;
            }
            case Tipo.Lista:
                return ((ComboBox)ctl).SelectedItem?.ToString();
            default:   // Texto, Area, Foto
            {
                string s = ctl.Text.Trim();
                if (s == "")
                {
                    if (c.Requerido) throw new ValidacionException("\"" + c.Etiqueta + "\" es obligatorio.");
                    return null;
                }
                if (c.Max > 0 && s.Length > c.Max)
                    throw new ValidacionException("\"" + c.Etiqueta + "\" admite máximo " + c.Max + " caracteres.");
                if (c.Email && !Regex.IsMatch(s, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                    throw new ValidacionException("El correo no tiene un formato válido.");
                return s;
            }
        }
    }

    private void Guardar(object sender, EventArgs ev)
    {
        try
        {
            var valores = new Dictionary<string, object>();
            foreach (Campo c in _e.Campos) valores[c.Col] = Leer(c);   // validación antes de enviar a la BD
            CrudDao.Guardar(_e, _id, valores);
            DialogResult = DialogResult.OK;
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));
        }
    }
}
