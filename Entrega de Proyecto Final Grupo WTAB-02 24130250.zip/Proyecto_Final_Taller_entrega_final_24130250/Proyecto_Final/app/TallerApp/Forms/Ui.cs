using System.Data;
using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Utilidades de interfaz.</summary>
public static class Ui
{
    private const string Titulo = "Taller El Rápido";
    public static readonly Color Primario = Color.FromArgb(31, 58, 95);
    public static readonly Color Exito = Color.FromArgb(46, 125, 50);
    public static readonly Color Advertencia = Color.FromArgb(232, 116, 30);
    public static readonly Color Peligro = Color.FromArgb(183, 28, 28);
    public static readonly Color Neutro = Color.FromArgb(230, 233, 238);

    public static void Error(string mensaje) =>
        MessageBox.Show(mensaje, Titulo, MessageBoxButtons.OK, MessageBoxIcon.Error);

    public static void Info(string mensaje) =>
        MessageBox.Show(mensaje, Titulo, MessageBoxButtons.OK, MessageBoxIcon.Information);

    public static bool Confirmar(string mensaje) =>
        MessageBox.Show(mensaje, Titulo, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;

    public static Label Etiqueta(string texto, int x, int y, int ancho = 170) =>
        new Label { Text = texto, Left = x, Top = y + 4, Width = ancho };

    public static void EstilizarBoton(Button boton, Color fondo, Color texto)
    {
        boton.BackColor = fondo;
        boton.ForeColor = texto;
        boton.FlatStyle = FlatStyle.Flat;
        boton.FlatAppearance.BorderSize = 0;
        boton.FlatAppearance.MouseOverBackColor = ControlPaint.Light(fondo);
        boton.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(fondo);
        boton.UseVisualStyleBackColor = false;
        boton.Cursor = Cursors.Hand;
    }

    /// <summary>Llena un ComboBox con una consulta (id, texto), con una fila vacía al inicio.</summary>
    public static void LlenarCombo(ComboBox cb, string sql)
    {
        DataTable dt = CrudDao.Combo(sql);
        dt.Rows.InsertAt(CrearVacia(dt), 0);
        cb.DropDownStyle = ComboBoxStyle.DropDownList;
        cb.DisplayMember = "texto";
        cb.ValueMember = "id";
        cb.DataSource = dt;
    }

    private static DataRow CrearVacia(DataTable dt)
    {
        DataRow r = dt.NewRow();
        r["id"] = DBNull.Value;
        r["texto"] = "-- seleccionar --";
        return r;
    }

    public static int? IdSeleccionado(ComboBox cb) =>
        cb.SelectedValue == null || cb.SelectedValue is DBNull ? null : Convert.ToInt32(cb.SelectedValue);
}
