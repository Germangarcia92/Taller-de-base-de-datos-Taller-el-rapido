using MySql.Data.MySqlClient;
using TallerApp.Data;

namespace TallerApp.Forms;

/// <summary>Inicio de sesión: elige el perfil y abre la conexión con su usuario de BD.</summary>
public class LoginForm : Form
{
    private readonly ComboBox _perfil = new() { DropDownStyle = ComboBoxStyle.DropDownList, Left = 130, Top = 70, Width = 220 };
    private readonly TextBox _password = new() { UseSystemPasswordChar = true, Left = 130, Top = 105, Width = 145 };
    private readonly Label _usuario = new() { Left = 130, Top = 138, Width = 220, ForeColor = Color.DimGray };
    private readonly Button _mostrarPassword = new() { Text = "Mostrar", Left = 280, Top = 105, Width = 70 };

    public LoginForm()
    {
        Text = "Taller El Rápido · Inicio de sesión";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterScreen;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(380, 230);

        var titulo = new Label
        {
            Text = "Taller El Rápido", Left = 20, Top = 18, AutoSize = true,
            Font = new Font("Segoe UI", 16, FontStyle.Bold), ForeColor = Ui.Primario
        };
        var entrar = new Button { Text = "Entrar", Left = 130, Top = 170, Width = 100 };
        var salir = new Button { Text = "Salir", Left = 250, Top = 170, Width = 100, DialogResult = DialogResult.Cancel };
        Ui.EstilizarBoton(entrar, Ui.Advertencia, Color.White);
        Ui.EstilizarBoton(salir, Ui.Neutro, Ui.Primario);
        Ui.EstilizarBoton(_mostrarPassword, Ui.Primario, Color.White);

        _perfil.Items.AddRange(Db.Perfiles().ToArray());
        _perfil.SelectedIndexChanged += (s, e) =>
            _usuario.Text = "Usuario de BD: " + Db.UsuarioDe((string)_perfil.SelectedItem);
        _perfil.SelectedIndex = 0;
        entrar.Click += Entrar;
        _mostrarPassword.Click += (s, e) =>
        {
            _password.UseSystemPasswordChar = !_password.UseSystemPasswordChar;
            _mostrarPassword.Text = _password.UseSystemPasswordChar ? "Mostrar" : "Ocultar";
        };

        Controls.AddRange(new Control[]
        {
            titulo, Ui.Etiqueta("Perfil", 20, 70, 100), _perfil,
            Ui.Etiqueta("Contraseña", 20, 105, 100), _password, _mostrarPassword, _usuario, entrar, salir
        });
        AcceptButton = entrar;
        CancelButton = salir;
    }

    private void Entrar(object sender, EventArgs e)
    {
        try
        {
            Db.IniciarSesion((string)_perfil.SelectedItem, _password.Text);
            DialogResult = DialogResult.OK;
        }
        catch (Exception ex)
        {
            Ui.Error(Errores.Mensaje(ex));
        }
    }
}
