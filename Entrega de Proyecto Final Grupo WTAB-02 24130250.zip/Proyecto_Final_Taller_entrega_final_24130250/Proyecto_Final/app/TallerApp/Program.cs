using TallerApp.Forms;

namespace TallerApp;

internal static class Program
{
    /// <summary>Punto de entrada (Main) de la aplicación.</summary>
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        while (true)
        {
            using (var login = new LoginForm())
            {
                if (login.ShowDialog() != DialogResult.OK) return;
            }
            var principal = new MainForm();
            Application.Run(principal);
            if (!principal.CerrarSesion) return;
        }
    }
}
