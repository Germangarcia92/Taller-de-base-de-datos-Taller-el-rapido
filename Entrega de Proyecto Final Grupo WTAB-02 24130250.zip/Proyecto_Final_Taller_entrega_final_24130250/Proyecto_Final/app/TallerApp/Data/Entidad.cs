namespace TallerApp.Data;

public enum Tipo { Texto, Area, Numero, Fecha, Combo, Lista, Foto }

public class Campo
{
    public string Col, Etiqueta;
    public Tipo Tipo;
    public bool Requerido, Entero, Email;
    public int Max;
    public string ComboSql;      // SELECT ... AS id, ... AS texto
    public string[] Opciones;
    public string Defecto;       // valor inicial en altas

    public static Campo Texto(string col, string et, bool req, int max, bool email = false) =>
        new() { Col = col, Etiqueta = et, Tipo = Tipo.Texto, Requerido = req, Max = max, Email = email };
    public static Campo Area(string col, string et, bool req, int max) =>
        new() { Col = col, Etiqueta = et, Tipo = Tipo.Area, Requerido = req, Max = max };
    public static Campo Numero(string col, string et, bool req, bool entero, string defecto = null) =>
        new() { Col = col, Etiqueta = et, Tipo = Tipo.Numero, Requerido = req, Entero = entero, Defecto = defecto };
    public static Campo Fecha(string col, string et, bool req) =>
        new() { Col = col, Etiqueta = et, Tipo = Tipo.Fecha, Requerido = req };
    public static Campo Combo(string col, string et, bool req, string sql) =>
        new() { Col = col, Etiqueta = et, Tipo = Tipo.Combo, Requerido = req, ComboSql = sql };
    public static Campo Lista(string col, string et, params string[] opciones) =>
        new() { Col = col, Etiqueta = et, Tipo = Tipo.Lista, Requerido = true, Opciones = opciones };
    public static Campo Foto(string col) =>
        new() { Col = col, Etiqueta = "Foto", Tipo = Tipo.Foto };
}

/// <summary>Describe una tabla: su SQL escrito a mano y los campos del formulario.</summary>
public class Entidad
{
    public string Titulo, Tabla, Pk;
    public string SelectSql;          // listado (sin WHERE); la primera columna es el ID
    public string InsertSql, UpdateSql, DeleteSql;
    public string TextoCol, TextoEtiqueta;                 // filtro por texto (LIKE)
    public string RangoCol, RangoEtiqueta; public bool RangoFecha;   // filtro por rango (BETWEEN)
    public List<Campo> Campos = new();
}
