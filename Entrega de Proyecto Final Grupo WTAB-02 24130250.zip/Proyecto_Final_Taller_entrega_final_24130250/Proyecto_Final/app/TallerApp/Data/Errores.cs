using MySql.Data.MySqlClient;

namespace TallerApp.Data;

public class ValidacionException : Exception
{
    public ValidacionException(string mensaje) : base(mensaje) { }
}

/// <summary>Traduce errores de MySQL a mensajes comprensibles para el usuario.</summary>
public static class Errores
{
    public static string Mensaje(Exception ex)
    {
        if (ex is ValidacionException) return ex.Message;
        if (ex is MySqlException m)
        {
            switch (m.Number)
            {
                case 1062: return "Valor duplicado: ya existe un registro con esa placa, correo, código o nombre.";
                case 1451: return "No se puede eliminar: otros registros dependen de éste (llave foránea).";
                case 1452: return "El registro relacionado seleccionado no existe (llave foránea).";
                case 3819:
                case 4025: return "Un valor no cumple una regla de validación (CHECK): revisa precios, años o cantidades.";
                case 1048: return "Falta un dato obligatorio.";
                case 1406: return "Un texto es demasiado largo para el campo.";
                case 1044:
                case 1142:
                case 1143:
                case 1370: return "PERMISOS: tu perfil (" + Db.Perfil + ") no tiene autorización para realizar esta acción.";
                case 1045: return "Usuario o contraseña incorrectos.";
                case 1644: return m.Message;   // SIGNAL de procedimientos y triggers
                case 0: return "No se pudo conectar con MySQL. Verifica que el servicio esté activo y la cadena \"taller\" en appsettings.json.";
                default: return "Error de base de datos (" + m.Number + "): " + m.Message;
            }
        }
        return ex.Message;
    }
}
