using System.Text.Json;
using MySql.Data.MySqlClient;

namespace TallerApp.Data;

/// <summary>
/// Configuración y conexión. La cadena de conexión "taller" vive en appsettings.json;
/// el usuario de BD lo determina el perfil elegido en el login (nunca root).
/// </summary>
public static class Db
{
    private static readonly JsonElement Config;
    private static string _cadena;

    public static string Perfil { get; private set; } = "";
    public static string Usuario { get; private set; } = "";
    public static bool EsAdmin => Perfil == "Administrador";
    public static bool EsConsulta => Perfil == "Consulta";

    static Db()
    {
        string ruta = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        Config = JsonDocument.Parse(File.ReadAllText(ruta)).RootElement;
    }

    public static List<string> Perfiles() =>
        Config.GetProperty("Perfiles").EnumerateObject().Select(p => p.Name).ToList();

    public static string UsuarioDe(string perfil) =>
        Config.GetProperty("Perfiles").GetProperty(perfil).GetString();

    /// <summary>Abre una conexión de prueba con el usuario del perfil; lanza MySqlException si falla.</summary>
    public static void IniciarSesion(string perfil, string password)
    {
        string usuario = UsuarioDe(perfil);
        var b = new MySqlConnectionStringBuilder(
            Config.GetProperty("ConnectionStrings").GetProperty("taller").GetString())
        {
            UserID = usuario,
            Password = password
        };
        using (var cn = new MySqlConnection(b.ConnectionString))
        {
            cn.Open();
        }
        _cadena = b.ConnectionString;
        Perfil = perfil;
        Usuario = usuario;
    }

    /// <summary>Devuelve una conexión abierta. Quien la pide debe cerrarla con using.</summary>
    public static MySqlConnection Abrir()
    {
        var cn = new MySqlConnection(_cadena);
        cn.Open();
        return cn;
    }
}
