namespace TallerApp.Data;

/// <summary>Las 6 tablas del taller con su SQL parametrizado escrito a mano.</summary>
public static class Entidades
{
    private const string CmbClientes = "SELECT id_cliente AS id, CONCAT(nombre,' ',apellidos) AS texto FROM cliente ORDER BY texto";
    public const string CmbVehiculos = "SELECT id_vehiculo AS id, CONCAT(placa,' - ',marca,' ',modelo) AS texto FROM vehiculo ORDER BY texto";
    public const string CmbServicios = "SELECT id_tipo_servicio AS id, nombre AS texto FROM tipo_servicio ORDER BY texto";
    public const string CmbEmpleados = "SELECT id_empleado AS id, CONCAT(nombre,' ',apellidos) AS texto FROM empleado ORDER BY texto";
    public const string CmbHerramientas = "SELECT id_herramienta AS id, nombre AS texto FROM herramienta ORDER BY texto";
    public const string CmbClientesPub = CmbClientes;

    public static readonly List<Entidad> Todas = new()
    {
        Ordenes(), Clientes(), Vehiculos(), Servicios(), Herramientas(), Empleados()
    };

    private static Entidad Clientes() => new()
    {
        Titulo = "Clientes", Tabla = "cliente", Pk = "id_cliente",
        SelectSql = "SELECT t.id_cliente AS `ID`, t.nombre AS `Nombre`, t.apellidos AS `Apellidos`, " +
                    "t.telefono AS `Teléfono`, t.email AS `Correo`, t.direccion AS `Dirección` FROM cliente t",
        InsertSql = "INSERT INTO cliente (nombre, apellidos, telefono, email, direccion) " +
                    "VALUES (@nombre, @apellidos, @telefono, @email, @direccion)",
        UpdateSql = "UPDATE cliente SET nombre=@nombre, apellidos=@apellidos, telefono=@telefono, " +
                    "email=@email, direccion=@direccion WHERE id_cliente=@id",
        DeleteSql = "DELETE FROM cliente WHERE id_cliente=@id",
        TextoCol = "CONCAT(t.nombre,' ',t.apellidos)", TextoEtiqueta = "Nombre contiene",
        Campos =
        {
            Campo.Texto("nombre", "Nombre", true, 60),
            Campo.Texto("apellidos", "Apellidos", true, 80),
            Campo.Texto("telefono", "Teléfono", true, 20),
            Campo.Texto("email", "Correo", false, 100, email: true),
            Campo.Texto("direccion", "Dirección", false, 150)
        }
    };

    private static Entidad Vehiculos() => new()
    {
        Titulo = "Vehículos", Tabla = "vehiculo", Pk = "id_vehiculo",
        SelectSql = "SELECT t.id_vehiculo AS `ID`, CONCAT(c.nombre,' ',c.apellidos) AS `Cliente`, t.placa AS `Placa`, " +
                    "t.marca AS `Marca`, t.modelo AS `Modelo`, t.anio AS `Año`, t.color AS `Color` " +
                    "FROM vehiculo t INNER JOIN cliente c ON c.id_cliente = t.id_cliente",
        InsertSql = "INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio, color, foto) " +
                    "VALUES (@id_cliente, @placa, @marca, @modelo, @anio, @color, @foto)",
        UpdateSql = "UPDATE vehiculo SET id_cliente=@id_cliente, placa=@placa, marca=@marca, modelo=@modelo, " +
                    "anio=@anio, color=@color, foto=@foto WHERE id_vehiculo=@id",
        DeleteSql = "DELETE FROM vehiculo WHERE id_vehiculo=@id",
        TextoCol = "CONCAT(t.placa,' ',t.marca,' ',t.modelo)", TextoEtiqueta = "Placa/marca/modelo contiene",
        RangoCol = "t.anio", RangoEtiqueta = "Año entre", RangoFecha = false,
        Campos =
        {
            Campo.Combo("id_cliente", "Cliente", true, CmbClientes),
            Campo.Texto("placa", "Placa", true, 12),
            Campo.Texto("marca", "Marca", true, 40),
            Campo.Texto("modelo", "Modelo", true, 40),
            Campo.Numero("anio", "Año", true, true),
            Campo.Texto("color", "Color", false, 30),
            Campo.Foto("foto")
        }
    };

    private static Entidad Servicios() => new()
    {
        Titulo = "Tipos de servicio", Tabla = "tipo_servicio", Pk = "id_tipo_servicio",
        SelectSql = "SELECT t.id_tipo_servicio AS `ID`, t.nombre AS `Servicio`, t.descripcion AS `Descripción`, " +
                    "t.precio_base AS `Precio base`, fn_costo_con_iva(t.precio_base) AS `Precio con IVA`, " +
                    "t.duracion_horas AS `Horas` FROM tipo_servicio t",
        InsertSql = "INSERT INTO tipo_servicio (nombre, descripcion, precio_base, duracion_horas, foto) " +
                    "VALUES (@nombre, @descripcion, @precio_base, @duracion_horas, @foto)",
        UpdateSql = "UPDATE tipo_servicio SET nombre=@nombre, descripcion=@descripcion, precio_base=@precio_base, " +
                    "duracion_horas=@duracion_horas, foto=@foto WHERE id_tipo_servicio=@id",
        DeleteSql = "DELETE FROM tipo_servicio WHERE id_tipo_servicio=@id",
        TextoCol = "t.nombre", TextoEtiqueta = "Nombre contiene",
        RangoCol = "t.precio_base", RangoEtiqueta = "Precio entre", RangoFecha = false,
        Campos =
        {
            Campo.Texto("nombre", "Nombre", true, 80),
            Campo.Texto("descripcion", "Descripción", false, 255),
            Campo.Numero("precio_base", "Precio base ($)", true, false),
            Campo.Numero("duracion_horas", "Duración (horas)", true, false),
            Campo.Foto("foto")
        }
    };

    private static Entidad Herramientas() => new()
    {
        Titulo = "Herramientas", Tabla = "herramienta", Pk = "id_herramienta",
        SelectSql = "SELECT t.id_herramienta AS `ID`, t.nombre AS `Herramienta`, t.marca AS `Marca`, t.codigo AS `Código`, " +
                    "t.cantidad_disponible AS `Disponibles`, t.estado AS `Estado` FROM herramienta t",
        InsertSql = "INSERT INTO herramienta (nombre, marca, codigo, cantidad_disponible, estado, foto) " +
                    "VALUES (@nombre, @marca, @codigo, @cantidad_disponible, @estado, @foto)",
        UpdateSql = "UPDATE herramienta SET nombre=@nombre, marca=@marca, codigo=@codigo, " +
                    "cantidad_disponible=@cantidad_disponible, estado=@estado, foto=@foto WHERE id_herramienta=@id",
        DeleteSql = "DELETE FROM herramienta WHERE id_herramienta=@id",
        TextoCol = "CONCAT(t.nombre,' ',IFNULL(t.marca,''))", TextoEtiqueta = "Nombre/marca contiene",
        RangoCol = "t.cantidad_disponible", RangoEtiqueta = "Disponibles entre", RangoFecha = false,
        Campos =
        {
            Campo.Texto("nombre", "Nombre", true, 80),
            Campo.Texto("marca", "Marca", false, 50),
            Campo.Texto("codigo", "Código", true, 20),
            Campo.Numero("cantidad_disponible", "Cantidad disponible", true, true),
            Campo.Lista("estado", "Estado", "Disponible", "En uso", "Mantenimiento"),
            Campo.Foto("foto")
        }
    };

    private static Entidad Empleados() => new()
    {
        Titulo = "Responsables (empleados)", Tabla = "empleado", Pk = "id_empleado",
        SelectSql = "SELECT t.id_empleado AS `ID`, t.nombre AS `Nombre`, t.apellidos AS `Apellidos`, t.puesto AS `Puesto`, " +
                    "t.telefono AS `Teléfono`, t.email AS `Correo`, t.fecha_contratacion AS `Contratación`, " +
                    "fn_antiguedad_anios(t.fecha_contratacion) AS `Antigüedad (años)` FROM empleado t",
        InsertSql = "INSERT INTO empleado (nombre, apellidos, puesto, telefono, email, fecha_contratacion, foto) " +
                    "VALUES (@nombre, @apellidos, @puesto, @telefono, @email, @fecha_contratacion, @foto)",
        UpdateSql = "UPDATE empleado SET nombre=@nombre, apellidos=@apellidos, puesto=@puesto, telefono=@telefono, " +
                    "email=@email, fecha_contratacion=@fecha_contratacion, foto=@foto WHERE id_empleado=@id",
        DeleteSql = "DELETE FROM empleado WHERE id_empleado=@id",
        TextoCol = "CONCAT(t.nombre,' ',t.apellidos,' ',t.puesto)", TextoEtiqueta = "Nombre/puesto contiene",
        RangoCol = "t.fecha_contratacion", RangoEtiqueta = "Contratado entre", RangoFecha = true,
        Campos =
        {
            Campo.Texto("nombre", "Nombre", true, 60),
            Campo.Texto("apellidos", "Apellidos", true, 80),
            Campo.Texto("puesto", "Puesto", true, 60),
            Campo.Texto("telefono", "Teléfono", false, 15),
            Campo.Texto("email", "Correo", true, 100, email: true),
            Campo.Fecha("fecha_contratacion", "Fecha de contratación", true),
            Campo.Foto("foto")
        }
    };

    private static Entidad Ordenes() => new()
    {
        Titulo = "Órdenes de servicio", Tabla = "orden_servicio", Pk = "id_orden",
        SelectSql = "SELECT t.id_orden AS `ID`, t.fecha_ingreso AS `Ingreso`, v.placa AS `Placa`, s.nombre AS `Servicio`, " +
                    "CONCAT(e.nombre,' ',e.apellidos) AS `Responsable`, h.nombre AS `Herramienta`, " +
                    "t.estado AS `Estado`, t.costo AS `Costo` " +
                    "FROM orden_servicio t " +
                    "INNER JOIN vehiculo v ON v.id_vehiculo = t.id_vehiculo " +
                    "INNER JOIN tipo_servicio s ON s.id_tipo_servicio = t.id_tipo_servicio " +
                    "INNER JOIN empleado e ON e.id_empleado = t.id_empleado " +
                    "LEFT JOIN herramienta h ON h.id_herramienta = t.id_herramienta",
        InsertSql = "INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, id_herramienta, " +
                    "fecha_ingreso, estado, costo, observaciones) " +
                    "VALUES (@id_vehiculo, @id_tipo_servicio, @id_empleado, @id_herramienta, @fecha_ingreso, @estado, @costo, @observaciones)",
        UpdateSql = "UPDATE orden_servicio SET id_vehiculo=@id_vehiculo, id_tipo_servicio=@id_tipo_servicio, " +
                    "id_empleado=@id_empleado, id_herramienta=@id_herramienta, fecha_ingreso=@fecha_ingreso, " +
                    "estado=@estado, costo=@costo, observaciones=@observaciones WHERE id_orden=@id",
        DeleteSql = "DELETE FROM orden_servicio WHERE id_orden=@id",
        TextoCol = "CONCAT(v.placa,' ',s.nombre,' ',t.estado)", TextoEtiqueta = "Placa/servicio/estado contiene",
        RangoCol = "t.fecha_ingreso", RangoEtiqueta = "Ingreso entre", RangoFecha = true,
        Campos =
        {
            Campo.Combo("id_vehiculo", "Vehículo", true, CmbVehiculos),
            Campo.Combo("id_tipo_servicio", "Servicio", true, CmbServicios),
            Campo.Combo("id_empleado", "Responsable", true, CmbEmpleados),
            Campo.Combo("id_herramienta", "Herramienta", false, CmbHerramientas),
            Campo.Fecha("fecha_ingreso", "Fecha de ingreso", true),
            Campo.Lista("estado", "Estado", "Pendiente", "En proceso", "Terminado", "Entregado"),
            Campo.Numero("costo", "Costo ($, 0 = precio base)", true, false, "0"),
            Campo.Area("observaciones", "Observaciones", false, 255)
        }
    };
}
