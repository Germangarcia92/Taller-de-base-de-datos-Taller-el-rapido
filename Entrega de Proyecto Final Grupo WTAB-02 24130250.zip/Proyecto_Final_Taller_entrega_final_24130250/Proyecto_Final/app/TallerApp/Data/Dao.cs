using System.Data;
using System.Text;
using MySql.Data.MySqlClient;

namespace TallerApp.Data;

/// <summary>Capa de acceso a datos: CRUD genérico. Todo con parámetros, jamás concatenando valores.</summary>
public static class CrudDao
{
    public static DataTable Listar(Entidad e, string texto, object desde, object hasta)
    {
        var sql = new StringBuilder(e.SelectSql + " WHERE 1=1");
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand { Connection = cn };

        if (!string.IsNullOrWhiteSpace(texto))
        {
            sql.Append(" AND ").Append(e.TextoCol).Append(" LIKE @q");
            cmd.Parameters.AddWithValue("@q", "%" + texto.Trim() + "%");
        }
        if (e.RangoCol != null && desde != null)
        {
            sql.Append(" AND ").Append(e.RangoCol).Append(" >= @desde");
            cmd.Parameters.AddWithValue("@desde", desde);
        }
        if (e.RangoCol != null && hasta != null)
        {
            sql.Append(" AND ").Append(e.RangoCol).Append(" <= @hasta");
            cmd.Parameters.AddWithValue("@hasta", hasta);
        }
        sql.Append(" ORDER BY 1 DESC");
        cmd.CommandText = sql.ToString();

        var tabla = new DataTable();
        using var rd = cmd.ExecuteReader();
        tabla.Load(rd);
        return tabla;
    }

    public static Dictionary<string, object> Obtener(Entidad e, int id)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand("SELECT * FROM " + e.Tabla + " WHERE " + e.Pk + " = @id", cn);
        cmd.Parameters.AddWithValue("@id", id);
        using var rd = cmd.ExecuteReader();
        var fila = new Dictionary<string, object>();
        if (rd.Read())
            for (int i = 0; i < rd.FieldCount; i++)
                fila[rd.GetName(i)] = rd.IsDBNull(i) ? null : rd.GetValue(i);
        return fila;
    }

    public static void Guardar(Entidad e, int? id, Dictionary<string, object> valores)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand(id == null ? e.InsertSql : e.UpdateSql, cn);
        foreach (var c in e.Campos)
            cmd.Parameters.AddWithValue("@" + c.Col, valores[c.Col] ?? DBNull.Value);
        if (id != null) cmd.Parameters.AddWithValue("@id", id.Value);
        cmd.ExecuteNonQuery();
    }

    public static void Eliminar(Entidad e, int id)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand(e.DeleteSql, cn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }

    /// <summary>Carga un combo (columnas id y texto) con un DataTable propio, sin restricciones de llave.</summary>
    public static DataTable Combo(string sql)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand(sql, cn);
        var tabla = new DataTable();
        tabla.Columns.Add("id", typeof(int));
        tabla.Columns.Add("texto", typeof(string));
        using var rd = cmd.ExecuteReader();
        while (rd.Read())
            tabla.Rows.Add(rd.GetInt32(0), rd.IsDBNull(1) ? "" : rd.GetString(1));
        return tabla;
    }
}

/// <summary>Reportes: vistas, joins, subconsultas, UNION y procedimientos almacenados.</summary>
public static class ReporteDao
{
    public static DataTable Ejecutar(string sql, bool esProcedimiento, params MySqlParameter[] parametros)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand(sql, cn);
        if (esProcedimiento) cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddRange(parametros);
        var tabla = new DataTable();
        using var rd = cmd.ExecuteReader();
        tabla.Load(rd);
        return tabla;
    }
}

/// <summary>Operaciones de negocio: transacción en C# y procedimientos con parámetro OUT.</summary>
public static class OperacionesDao
{
    /// <summary>
    /// Alta de cliente + vehículo en UNA transacción (MySqlTransaction).
    /// Si el segundo INSERT falla (p. ej. placa duplicada) se hace ROLLBACK y el cliente tampoco queda guardado.
    /// </summary>
    public static int AltaClienteConVehiculo(string nombre, string apellidos, string telefono,
                                             string placa, string marca, string modelo, int anio)
    {
        using var cn = Db.Abrir();
        using var tx = cn.BeginTransaction();
        try
        {
            long idCliente;
            using (var c1 = new MySqlCommand(
                "INSERT INTO cliente (nombre, apellidos, telefono) VALUES (@nombre, @apellidos, @telefono)", cn, tx))
            {
                c1.Parameters.AddWithValue("@nombre", nombre);
                c1.Parameters.AddWithValue("@apellidos", apellidos);
                c1.Parameters.AddWithValue("@telefono", telefono);
                c1.ExecuteNonQuery();
                idCliente = c1.LastInsertedId;
            }
            using (var c2 = new MySqlCommand(
                "INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio) " +
                "VALUES (@id_cliente, @placa, @marca, @modelo, @anio)", cn, tx))
            {
                c2.Parameters.AddWithValue("@id_cliente", idCliente);
                c2.Parameters.AddWithValue("@placa", placa);
                c2.Parameters.AddWithValue("@marca", marca);
                c2.Parameters.AddWithValue("@modelo", modelo);
                c2.Parameters.AddWithValue("@anio", anio);
                c2.ExecuteNonQuery();
            }
            tx.Commit();
            return (int)idCliente;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    /// <summary>sp_registrar_orden: devuelve el id generado por el parámetro OUT.</summary>
    public static int RegistrarOrden(int idVehiculo, int idServicio, int idEmpleado, int? idHerramienta,
                                     DateTime fecha, string observaciones)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand("sp_registrar_orden", cn) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.Add(new MySqlParameter("p_id_vehiculo", MySqlDbType.Int32) { Value = idVehiculo });
        cmd.Parameters.Add(new MySqlParameter("p_id_tipo_servicio", MySqlDbType.Int32) { Value = idServicio });
        cmd.Parameters.Add(new MySqlParameter("p_id_empleado", MySqlDbType.Int32) { Value = idEmpleado });
        cmd.Parameters.Add(new MySqlParameter("p_id_herramienta", MySqlDbType.Int32) { Value = (object)idHerramienta ?? DBNull.Value });
        cmd.Parameters.Add(new MySqlParameter("p_fecha", MySqlDbType.Date) { Value = fecha.Date });
        cmd.Parameters.Add(new MySqlParameter("p_observaciones", MySqlDbType.VarChar) { Value = (object)observaciones ?? DBNull.Value });
        var pOut = new MySqlParameter("p_id_orden", MySqlDbType.Int32) { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(pOut);
        cmd.ExecuteNonQuery();
        return Convert.ToInt32(pOut.Value);
    }

    /// <summary>sp_cambiar_estado_orden: dispara los triggers de bitácora e inventario.</summary>
    public static void CambiarEstado(int idOrden, string estado)
    {
        using var cn = Db.Abrir();
        using var cmd = new MySqlCommand("sp_cambiar_estado_orden", cn) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.Add(new MySqlParameter("p_id_orden", MySqlDbType.Int32) { Value = idOrden });
        cmd.Parameters.Add(new MySqlParameter("p_estado", MySqlDbType.VarChar) { Value = estado });
        cmd.ExecuteNonQuery();
    }

    /// <summary>sp_total_gastado_cliente: parámetro OUT + función fn_ordenes_cliente.</summary>
    public static (decimal total, int ordenes) TotalCliente(int idCliente)
    {
        using var cn = Db.Abrir();
        decimal total;
        using (var cmd = new MySqlCommand("sp_total_gastado_cliente", cn) { CommandType = CommandType.StoredProcedure })
        {
            cmd.Parameters.Add(new MySqlParameter("p_id_cliente", MySqlDbType.Int32) { Value = idCliente });
            var pOut = new MySqlParameter("p_total", MySqlDbType.Decimal) { Direction = ParameterDirection.Output };
            cmd.Parameters.Add(pOut);
            cmd.ExecuteNonQuery();
            total = Convert.ToDecimal(pOut.Value);
        }
        using var cmd2 = new MySqlCommand("SELECT fn_ordenes_cliente(@id)", cn);
        cmd2.Parameters.AddWithValue("@id", idCliente);
        int ordenes = Convert.ToInt32(cmd2.ExecuteScalar());
        return (total, ordenes);
    }
}
