-- ============================================================
--  02_datos.sql : carga inicial (15 registros por tabla)
-- ============================================================
USE taller_mecanico;

-- ---------- DATOS (15 por tabla) ----------
INSERT INTO tipo_servicio (nombre, descripcion, precio_base, duracion_horas) VALUES
('Cambio de aceite','Aceite y filtro',350,0.5),
('Afinación mayor','Bujías, filtros y limpieza de inyectores',1200,3),
('Cambio de frenos','Balatas y rectificado de discos',900,2),
('Alineación y balanceo','Cuatro llantas',600,1.5),
('Cambio de batería','Revisión del sistema de carga',250,0.5),
('Diagnóstico por computadora','Lectura de códigos OBD2',400,1),
('Cambio de llantas','Montaje y balanceo',300,1),
('Suspensión','Revisión y ajuste general',1800,4),
('Cambio de clutch','Kit completo de embrague',3500,6),
('Aire acondicionado','Carga de gas y revisión de fugas',850,2),
('Bomba de agua','Cambio con anticongelante',1400,3),
('Banda de distribución','Kit de distribución',2200,4),
('Escape y silenciador','Reparación o reemplazo',950,2),
('Reparación eléctrica','Cableado, fusibles y luces',700,2),
('Amortiguadores','Cambio de los cuatro',1600,3);

INSERT INTO herramienta (nombre, marca, codigo, cantidad_disponible, estado) VALUES
('Llave de impacto','Dewalt','HR-001',4,'Disponible'),
('Gato hidráulico 3 ton','Truper','HR-002',3,'Disponible'),
('Juego de dados 1/2','Urrea','HR-003',6,'Disponible'),
('Torquímetro','Stanley','HR-004',2,'En uso'),
('Elevador de 2 columnas','Rotary','HR-005',2,'Disponible'),
('Escáner OBD2','Launch','HR-006',3,'Disponible'),
('Multímetro digital','Fluke','HR-007',4,'Disponible'),
('Compresor de aire','Campbell','HR-008',1,'Mantenimiento'),
('Extractor de balatas','Lisle','HR-009',2,'Disponible'),
('Cargador de baterías','Bosch','HR-010',3,'Disponible'),
('Pistola neumática','Ingersoll','HR-011',5,'Disponible'),
('Alineador láser','Hunter','HR-012',1,'Disponible'),
('Desmontadora de llantas','Hofmann','HR-013',1,'En uso'),
('Probador de compresión','Actron','HR-014',2,'Disponible'),
('Juego de llaves españolas','Truper','HR-015',8,'Disponible');

INSERT INTO empleado (nombre, apellidos, puesto, telefono, email, fecha_contratacion) VALUES
('Raúl','Montoya Esquer','Jefe de taller','6441110001','raul.montoya@taller.com','2018-03-12'),
('Iván','Cota Beltrán','Mecánico general','6441110002','ivan.cota@taller.com','2019-06-01'),
('Gabriel','Soto Ibarra','Mecánico general','6441110003','gabriel.soto@taller.com','2019-09-15'),
('Marco','Leyva Duarte','Técnico en frenos','6441110004','marco.leyva@taller.com','2020-01-20'),
('Óscar','Valdez Peña','Técnico eléctrico','6441110005','oscar.valdez@taller.com','2020-05-04'),
('Andrés','Félix Acosta','Alineación y balanceo','6441110006','andres.felix@taller.com','2020-08-17'),
('Emilio','Zazueta Ruiz','Mecánico general','6441110007','emilio.zazueta@taller.com','2021-02-08'),
('Diego','Ochoa Salazar','Técnico en A/C','6441110008','diego.ochoa@taller.com','2021-07-26'),
('Hugo','Bojórquez Lara','Mecánico general','6441110009','hugo.bojorquez@taller.com','2022-01-10'),
('Sergio','Ramírez Cota','Diagnóstico','6441110010','sergio.ramirez@taller.com','2022-04-18'),
('Fabián','Gutiérrez Mena','Ayudante','6441110011','fabian.gutierrez@taller.com','2022-10-03'),
('Tomás','Valenzuela Ríos','Ayudante','6441110012','tomas.valenzuela@taller.com','2023-02-13'),
('Julián','Acuña Torres','Técnico en suspensión','6441110013','julian.acuna@taller.com','2023-06-05'),
('Adrián','Mendívil Cruz','Mecánico general','6441110014','adrian.mendivil@taller.com','2024-01-22'),
('Ximena','Carrillo Vega','Recepción y refacciones','6441110015','ximena.carrillo@taller.com','2024-05-06');

INSERT INTO cliente (nombre, apellidos, telefono, email, direccion) VALUES
('Juan Pablo','Aguirre Lugo','6441001001','juan.aguirre@mail.com','Calle Sonora 120, Col. Centro'),
('María Fernanda','López Ruiz','6441001002','maria.lopez@mail.com','Av. Miguel Alemán 455'),
('Carlos Alberto','Mendoza Páez','6441001003','carlos.mendoza@mail.com','Calle Jalisco 310'),
('Ana Lucía','Valenzuela Cota','6441001004','ana.valenzuela@mail.com','Blvd. Las Torres 88'),
('Luis Enrique','Duarte Soto','6441001005','luis.duarte@mail.com','Calle Guerrero 205'),
('Sofía','Ramírez Cota','6441001006','sofia.ramirez@mail.com','Col. Villa Sonora 14'),
('Jorge Armando','Bojórquez Reyes','6441001007','jorge.bojorquez@mail.com','Calle Hidalgo 67'),
('Daniela','Félix Montoya','6441001008','daniela.felix@mail.com','Fracc. Los Álamos 9'),
('Ricardo','Salazar Ibarra','6441001009','ricardo.salazar@mail.com','Calle Allende 172'),
('Paola','Gutiérrez Leyva','6441001010','paola.gutierrez@mail.com','Col. Nainari 301'),
('Miguel Ángel','Ochoa Zamora','6441001011','miguel.ochoa@mail.com','Calle Morelos 540'),
('Fernanda','Acosta Rivera','6441001012','fernanda.acosta@mail.com','Av. Kino 233'),
('Héctor Manuel','Zazueta Lara','6441001013','hector.zazueta@mail.com','Col. Cumuripa 45'),
('Valeria','Sánchez Peña','6441001014','valeria.sanchez@mail.com','Calle Náinari 18'),
('Roberto Carlos','Beltrán Medina','6441001015','roberto.beltran@mail.com','Calle Tetabiate 76');

INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio, color) VALUES
(1,'SON-101-A','Nissan','Versa',2018,'Blanco'),
(2,'SON-102-B','Toyota','Corolla',2020,'Gris'),
(3,'SON-103-C','Chevrolet','Silverado',2017,'Negro'),
(4,'SON-104-D','Ford','Ranger',2019,'Rojo'),
(5,'SON-105-E','Honda','Civic',2016,'Azul'),
(6,'SON-106-F','Volkswagen','Jetta',2015,'Plata'),
(7,'SON-107-G','Mazda','3',2021,'Rojo'),
(8,'SON-108-H','Kia','Rio',2022,'Blanco'),
(9,'SON-109-J','Nissan','NP300',2014,'Blanco'),
(10,'SON-110-K','Hyundai','Tucson',2019,'Gris'),
(11,'SON-111-L','Toyota','Hilux',2018,'Negro'),
(12,'SON-112-M','Chevrolet','Aveo',2013,'Azul'),
(13,'SON-113-N','Ford','Focus',2012,'Plata'),
(14,'SON-114-P','Honda','CR-V',2020,'Blanco'),
(15,'SON-115-R','Dodge','Ram 1500',2016,'Negro');

INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, id_herramienta, fecha_ingreso, estado, observaciones) VALUES
(1,1,2,1,'2026-10-20','Entregado','Sin novedades'),
(2,3,4,9,'2026-10-22','Entregado','Se cambiaron balatas delanteras'),
(3,2,3,3,'2026-10-25','Terminado','Afinación completa'),
(4,6,10,6,'2026-10-27','Entregado','Falla en sensor de oxígeno'),
(5,4,6,12,'2026-10-29','Entregado','Alineación y balanceo'),
(6,5,5,10,'2026-11-02','Terminado','Batería nueva instalada'),
(7,1,2,1,'2026-11-03','Entregado','Aceite sintético'),
(8,10,8,7,'2026-11-05','En proceso','Revisando fuga de gas'),
(9,9,3,2,'2026-11-06','En proceso','Cliente pide presupuesto del clutch'),
(10,8,13,5,'2026-11-09','En proceso','Ruido en suspensión delantera'),
(11,12,9,3,'2026-11-10','Pendiente','Pendiente de refacciones'),
(12,14,5,7,'2026-11-11','Pendiente','Luces intermitentes fallando'),
(13,13,7,NULL,'2026-11-12','Pendiente','Escape con fuga'),
(14,15,13,5,'2026-11-13','Pendiente','Cambio de amortiguadores traseros'),
(15,7,6,13,'2026-11-14','Pendiente','Cuatro llantas nuevas');

-- El costo de cada orden parte del precio base del servicio.
UPDATE orden_servicio o
INNER JOIN tipo_servicio s ON s.id_tipo_servicio = o.id_tipo_servicio
SET o.costo = s.precio_base;
