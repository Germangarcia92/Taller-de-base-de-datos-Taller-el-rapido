-- ============================================================
--  04_procedural.sql : funciones, procedimientos, triggers y
--                      privilegios de ejecución
-- ============================================================
USE taller_mecanico;
DELIMITER $$

-- ---------- 5.2 FUNCIONES ----------
CREATE FUNCTION fn_costo_con_iva(p_precio DECIMAL(10,2)) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
  RETURN ROUND(p_precio * 1.16, 2);
END$$

CREATE FUNCTION fn_antiguedad_anios(p_fecha DATE) RETURNS INT
DETERMINISTIC
BEGIN
  RETURN TIMESTAMPDIFF(YEAR, p_fecha, CURDATE());
END$$

CREATE FUNCTION fn_ordenes_cliente(p_id_cliente INT) RETURNS INT
READS SQL DATA
BEGIN
  DECLARE v_total INT;
  SELECT COUNT(*) INTO v_total
  FROM orden_servicio o
  INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo
  WHERE v.id_cliente = p_id_cliente;
  RETURN v_total;
END$$

-- ---------- 5.1 PROCEDIMIENTOS ----------
-- 1) Registrar orden (parámetro OUT + manejo de errores con HANDLER)
CREATE PROCEDURE sp_registrar_orden(
  IN  p_id_vehiculo      INT,
  IN  p_id_tipo_servicio INT,
  IN  p_id_empleado      INT,
  IN  p_id_herramienta   INT,
  IN  p_fecha            DATE,
  IN  p_observaciones    VARCHAR(255),
  OUT p_id_orden         INT)
BEGIN
  DECLARE v_estado VARCHAR(20);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  IF p_id_herramienta IS NOT NULL THEN
    SELECT estado INTO v_estado FROM herramienta WHERE id_herramienta = p_id_herramienta;
    IF v_estado = 'Mantenimiento' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La herramienta seleccionada está en mantenimiento.';
    END IF;
  END IF;
  INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, id_herramienta, fecha_ingreso, observaciones)
  VALUES (p_id_vehiculo, p_id_tipo_servicio, p_id_empleado, p_id_herramienta, p_fecha, p_observaciones);
  SET p_id_orden = LAST_INSERT_ID();
  COMMIT;
END$$

-- 2) Cambiar estado de una orden (valida existencia y flujo)
CREATE PROCEDURE sp_cambiar_estado_orden(IN p_id_orden INT, IN p_estado VARCHAR(20))
BEGIN
  DECLARE v_actual VARCHAR(20);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  SELECT estado INTO v_actual FROM orden_servicio WHERE id_orden = p_id_orden;
  IF v_actual IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La orden indicada no existe.';
  END IF;
  IF v_actual = 'Entregado' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Una orden entregada ya no se puede modificar.';
  END IF;
  UPDATE orden_servicio SET estado = p_estado WHERE id_orden = p_id_orden;
  COMMIT;
END$$

-- 3) Total gastado por un cliente (parámetro de salida)
CREATE PROCEDURE sp_total_gastado_cliente(IN p_id_cliente INT, OUT p_total DECIMAL(12,2))
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cliente WHERE id_cliente = p_id_cliente) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El cliente indicado no existe.';
  END IF;
  SELECT IFNULL(SUM(o.costo), 0) INTO p_total
  FROM orden_servicio o
  INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo
  WHERE v.id_cliente = p_id_cliente;
END$$

-- 4) Reporte con GROUP BY, HAVING, agregados, fecha, cadena, CAST y ORDER BY
CREATE PROCEDURE sp_reporte_servicios(IN p_desde DATE, IN p_hasta DATE, IN p_min_ordenes INT)
BEGIN
  SELECT DATE_FORMAT(o.fecha_ingreso, '%Y-%m')      AS mes,
         UPPER(s.nombre)                            AS servicio,
         COUNT(*)                                   AS total_ordenes,
         SUM(o.costo)                               AS ingresos,
         CAST(AVG(o.costo) AS DECIMAL(10,2))        AS costo_promedio,
         CONCAT('$', FORMAT(SUM(o.costo), 2))       AS ingresos_texto
  FROM orden_servicio o
  INNER JOIN tipo_servicio s ON s.id_tipo_servicio = o.id_tipo_servicio
  WHERE o.fecha_ingreso BETWEEN p_desde AND p_hasta
  GROUP BY mes, servicio
  HAVING COUNT(*) >= p_min_ordenes
  ORDER BY mes, ingresos DESC;
END$$

-- 5) Órdenes por estado (cadena vacía = todas)
CREATE PROCEDURE sp_ordenes_por_estado(IN p_estado VARCHAR(20))
BEGIN
  SELECT id_orden, fecha_ingreso, estado, costo, placa, vehiculo, cliente, servicio, responsable, herramienta
  FROM v_ordenes_detalle
  WHERE p_estado = '' OR estado = p_estado
  ORDER BY fecha_ingreso DESC, id_orden DESC;
END$$

-- 6) Alta de cliente con su primer vehículo: dos tablas en una transacción
CREATE PROCEDURE sp_alta_cliente_vehiculo(
  IN  p_nombre    VARCHAR(60),  IN p_apellidos VARCHAR(80), IN p_telefono VARCHAR(20),
  IN  p_email     VARCHAR(100), IN p_direccion VARCHAR(150),
  IN  p_placa     VARCHAR(12),  IN p_marca VARCHAR(40), IN p_modelo VARCHAR(40),
  IN  p_anio      INT,          IN p_color VARCHAR(30),
  OUT p_id_cliente INT)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  START TRANSACTION;
  INSERT INTO cliente (nombre, apellidos, telefono, email, direccion)
  VALUES (p_nombre, p_apellidos, p_telefono, p_email, p_direccion);
  SET p_id_cliente = LAST_INSERT_ID();
  INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio, color)
  VALUES (p_id_cliente, p_placa, p_marca, p_modelo, p_anio, p_color);
  COMMIT;
END$$

-- ---------- 5.3 TRIGGERS ----------
-- 1) Validación de reglas de negocio + costo por defecto
CREATE TRIGGER trg_orden_bi BEFORE INSERT ON orden_servicio
FOR EACH ROW
BEGIN
  IF NEW.fecha_ingreso > CURDATE() THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La fecha de ingreso no puede ser futura.';
  END IF;
  IF NEW.costo = 0 THEN
    SET NEW.costo = IFNULL((SELECT precio_base FROM tipo_servicio
                            WHERE id_tipo_servicio = NEW.id_tipo_servicio), 0);
  END IF;
END$$

-- 2) Bitácora de cambios de estado
CREATE TRIGGER trg_orden_au_bitacora AFTER UPDATE ON orden_servicio
FOR EACH ROW
BEGIN
  IF NOT (OLD.estado <=> NEW.estado) THEN
    INSERT INTO bitacora_orden (id_orden, estado_anterior, estado_nuevo, usuario)
    VALUES (NEW.id_orden, OLD.estado, NEW.estado, USER());
  END IF;
END$$

-- 3) Inventario de herramientas: descuenta al iniciar, regresa al terminar
CREATE TRIGGER trg_orden_au_inventario AFTER UPDATE ON orden_servicio
FOR EACH ROW
BEGIN
  IF NEW.id_herramienta IS NOT NULL THEN
    IF OLD.estado <> 'En proceso' AND NEW.estado = 'En proceso' THEN
      UPDATE herramienta SET cantidad_disponible = cantidad_disponible - 1
      WHERE id_herramienta = NEW.id_herramienta;      -- el CHECK impide quedar en negativo
    ELSEIF OLD.estado = 'En proceso' AND NEW.estado IN ('Terminado', 'Entregado') THEN
      UPDATE herramienta SET cantidad_disponible = cantidad_disponible + 1
      WHERE id_herramienta = NEW.id_herramienta;
    END IF;
  END IF;
END$$

DELIMITER ;

-- ---------- Privilegios sobre rutinas (3.3) ----------
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_registrar_orden       TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_cambiar_estado_orden  TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_total_gastado_cliente TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_alta_cliente_vehiculo TO 'rol_operador';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_reporte_servicios     TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON PROCEDURE taller_mecanico.sp_ordenes_por_estado    TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON FUNCTION  taller_mecanico.fn_costo_con_iva         TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON FUNCTION  taller_mecanico.fn_antiguedad_anios      TO 'rol_operador', 'rol_consulta';
GRANT EXECUTE ON FUNCTION  taller_mecanico.fn_ordenes_cliente       TO 'rol_operador', 'rol_consulta';
