-- ============================================================
--  03_seguridad.sql : perfiles, roles, usuarios y privilegios
--  (los GRANT EXECUTE sobre procedimientos y funciones están al
--   final de 04_procedural.sql, porque esas rutinas aún no existen)
-- ============================================================
USE taller_mecanico;

-- 3.1 Perfiles de usuario
--   Administrador : todo el sistema, incluida la bitácora.
--   Operador      : atiende clientes, vehículos y órdenes; solo consulta
--                   empleados y servicios; no puede borrar nada.
--   Consulta      : solo ve las vistas de reportes (sin acceso a tablas).

-- 3.4 Roles (los permisos se otorgan al rol, no al usuario)
CREATE ROLE IF NOT EXISTS 'rol_admin', 'rol_operador', 'rol_consulta';

-- 3.3 Privilegios distintos por objeto
-- Administrador
GRANT ALL PRIVILEGES ON taller_mecanico.* TO 'rol_admin';

-- Operador: tablas
GRANT SELECT                 ON taller_mecanico.empleado       TO 'rol_operador';
GRANT SELECT                 ON taller_mecanico.tipo_servicio  TO 'rol_operador';
GRANT SELECT, INSERT, UPDATE ON taller_mecanico.cliente        TO 'rol_operador';
GRANT SELECT, INSERT, UPDATE ON taller_mecanico.vehiculo       TO 'rol_operador';
GRANT SELECT, INSERT, UPDATE ON taller_mecanico.orden_servicio TO 'rol_operador';
GRANT SELECT, UPDATE         ON taller_mecanico.herramienta    TO 'rol_operador';
-- Operador: vistas
GRANT SELECT ON taller_mecanico.v_ordenes_detalle    TO 'rol_operador';
GRANT SELECT ON taller_mecanico.v_vehiculos_cliente  TO 'rol_operador';
GRANT SELECT ON taller_mecanico.v_herramientas_uso   TO 'rol_operador';

-- Consulta: únicamente vistas
GRANT SELECT ON taller_mecanico.v_ordenes_detalle    TO 'rol_consulta';
GRANT SELECT ON taller_mecanico.v_vehiculos_cliente  TO 'rol_consulta';
GRANT SELECT ON taller_mecanico.v_herramientas_uso   TO 'rol_consulta';

-- GRANT y REVOKE: ejemplo de privilegio que se concede y luego se retira
GRANT DELETE ON taller_mecanico.cliente TO 'rol_operador';
REVOKE DELETE ON taller_mecanico.cliente FROM 'rol_operador';

-- 3.2 Creación de usuarios (nadie se conecta como root en la app)
CREATE USER IF NOT EXISTS 'taller_admin'@'localhost'    IDENTIFIED BY 'Admin123!';
CREATE USER IF NOT EXISTS 'taller_operador'@'localhost' IDENTIFIED BY 'Oper123!';
CREATE USER IF NOT EXISTS 'taller_consulta'@'localhost' IDENTIFIED BY 'Cons123!';

GRANT 'rol_admin'    TO 'taller_admin'@'localhost';
GRANT 'rol_operador' TO 'taller_operador'@'localhost';
GRANT 'rol_consulta' TO 'taller_consulta'@'localhost';
SET DEFAULT ROLE ALL TO 'taller_admin'@'localhost',
                        'taller_operador'@'localhost',
                        'taller_consulta'@'localhost';
FLUSH PRIVILEGES;

-- Verificación
SHOW GRANTS FOR 'taller_operador'@'localhost' USING 'rol_operador';
