-- ============================================================
--  06_concurrencia.sql : transacciones y niveles de aislamiento
--  Abre DOS pestañas de MySQL Workbench (Sesión A y Sesión B).
--  Ejecuta línea por línea en el orden indicado.
-- ============================================================
USE taller_mecanico;

-- ------------------------------------------------------------
-- 4.5 COMMIT / ROLLBACK: operación de negocio sobre 2 tablas
--     (alta de cliente + vehículo). La placa SON-101-A ya existe,
--     por lo que el segundo INSERT falla y se deshace todo.
-- ------------------------------------------------------------
START TRANSACTION;
INSERT INTO cliente (nombre, apellidos, telefono) VALUES ('Prueba', 'Rollback', '6440000000');
SET @id = LAST_INSERT_ID();
INSERT INTO vehiculo (id_cliente, placa, marca, modelo, anio)
VALUES (@id, 'SON-101-A', 'Test', 'Test', 2020);      -- ERROR 1062 (placa duplicada)
ROLLBACK;
SELECT COUNT(*) AS debe_ser_cero FROM cliente WHERE nombre = 'Prueba';

-- ------------------------------------------------------------
-- 4.4-a READ UNCOMMITTED -> LECTURA SUCIA
-- ------------------------------------------------------------
-- [Sesión A]
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
START TRANSACTION;
-- [Sesión B]
START TRANSACTION;
UPDATE tipo_servicio SET precio_base = 999 WHERE id_tipo_servicio = 1;   -- sin COMMIT
-- [Sesión A]
SELECT precio_base FROM tipo_servicio WHERE id_tipo_servicio = 1;        -- ve 999 (lectura sucia)
-- [Sesión B]
ROLLBACK;
-- [Sesión A]
SELECT precio_base FROM tipo_servicio WHERE id_tipo_servicio = 1;        -- vuelve a 350
COMMIT;

-- ------------------------------------------------------------
-- 4.4-b READ COMMITTED -> LECTURA NO REPETIBLE
-- ------------------------------------------------------------
-- [Sesión A]
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT precio_base FROM tipo_servicio WHERE id_tipo_servicio = 1;        -- 350
-- [Sesión B]
UPDATE tipo_servicio SET precio_base = 400 WHERE id_tipo_servicio = 1;   -- autocommit
-- [Sesión A]
SELECT precio_base FROM tipo_servicio WHERE id_tipo_servicio = 1;        -- 400: lectura no repetible
COMMIT;
-- Con REPEATABLE READ (por defecto en MySQL) Sesión A seguiría viendo 350 hasta su COMMIT.
-- Restaurar:
UPDATE tipo_servicio SET precio_base = 350 WHERE id_tipo_servicio = 1;

-- ------------------------------------------------------------
-- 4.4-c SERIALIZABLE -> BLOQUEO
-- ------------------------------------------------------------
-- [Sesión A]
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;
START TRANSACTION;
SELECT * FROM tipo_servicio WHERE id_tipo_servicio = 1;                  -- toma candado compartido
-- [Sesión B]
UPDATE tipo_servicio SET precio_base = 500 WHERE id_tipo_servicio = 1;   -- se queda esperando (bloqueo)
-- [Sesión A]
COMMIT;                                                                  -- B continúa
-- [Sesión B]  (si espera mucho: ERROR 1205 Lock wait timeout exceeded)
UPDATE tipo_servicio SET precio_base = 350 WHERE id_tipo_servicio = 1;   -- restaurar

-- ------------------------------------------------------------
-- 4.4-d FANTASMA en READ COMMITTED
-- ------------------------------------------------------------
-- [Sesión A]
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT COUNT(*) FROM orden_servicio WHERE estado = 'Pendiente';
-- [Sesión B]
INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, fecha_ingreso)
VALUES (1, 1, 2, CURDATE());
-- [Sesión A]
SELECT COUNT(*) FROM orden_servicio WHERE estado = 'Pendiente';          -- una fila "fantasma" más
COMMIT;

-- ------------------------------------------------------------
-- Trigger + ROLLBACK: inventario de herramientas
-- ------------------------------------------------------------
-- La herramienta 12 (Alineador láser) tiene 1 pieza. Se deja en 0 y se intenta
-- iniciar una orden que la usa: el CHECK falla dentro del trigger y todo se revierte.
UPDATE herramienta SET cantidad_disponible = 0 WHERE id_herramienta = 12;
INSERT INTO orden_servicio (id_vehiculo, id_tipo_servicio, id_empleado, id_herramienta, fecha_ingreso)
VALUES (2, 4, 6, 12, CURDATE());
SET @orden = LAST_INSERT_ID();
START TRANSACTION;
UPDATE orden_servicio SET estado = 'En proceso' WHERE id_orden = @orden;  -- ERROR 3819 (CHECK)
ROLLBACK;
SELECT estado FROM orden_servicio WHERE id_orden = @orden;               -- sigue 'Pendiente'
SELECT * FROM bitacora_orden ORDER BY id_bitacora DESC;                  -- no hay registro del intento
-- Restaurar datos de prueba
DELETE FROM orden_servicio WHERE id_orden = @orden;
UPDATE herramienta SET cantidad_disponible = 1 WHERE id_herramienta = 12;
