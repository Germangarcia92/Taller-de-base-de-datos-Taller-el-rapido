-- ============================================================
--  Proyecto Final - Taller de Base de Datos
--  Tema: Taller mecánico (equipo de 3: 6 tablas)
--  01_esquema.sql : CREATE DATABASE, tablas, constraints, ALTER,
--                   bitácora y vistas.  MySQL 8.x
-- ============================================================
DROP DATABASE IF EXISTS taller_mecanico;
CREATE DATABASE taller_mecanico CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE taller_mecanico;

-- Constraints usados: PRIMARY KEY, FOREIGN KEY (ON DELETE / ON UPDATE),
-- UNIQUE, CHECK y NOT NULL / DEFAULT.

CREATE TABLE tipo_servicio (
  id_tipo_servicio INT AUTO_INCREMENT PRIMARY KEY,
  nombre           VARCHAR(80)   NOT NULL UNIQUE,
  descripcion      VARCHAR(255),
  precio_base      DECIMAL(10,2) NOT NULL,
  duracion_horas   DECIMAL(4,1)  NOT NULL DEFAULT 1.0,
  foto             VARCHAR(120),
  CONSTRAINT ck_servicio_precio   CHECK (precio_base >= 0),
  CONSTRAINT ck_servicio_duracion CHECK (duracion_horas > 0)
);

CREATE TABLE herramienta (
  id_herramienta      INT AUTO_INCREMENT PRIMARY KEY,
  nombre              VARCHAR(80) NOT NULL,
  marca               VARCHAR(50),
  codigo              VARCHAR(20) NOT NULL UNIQUE,
  cantidad_disponible INT NOT NULL DEFAULT 1,
  estado              ENUM('Disponible','En uso','Mantenimiento') NOT NULL DEFAULT 'Disponible',
  foto                VARCHAR(120),
  CONSTRAINT ck_herr_cantidad CHECK (cantidad_disponible >= 0)
);

CREATE TABLE empleado (
  id_empleado        INT AUTO_INCREMENT PRIMARY KEY,
  nombre             VARCHAR(60)  NOT NULL,
  apellidos          VARCHAR(80)  NOT NULL,
  puesto             VARCHAR(60)  NOT NULL,
  telefono           VARCHAR(15),
  email              VARCHAR(100) NOT NULL UNIQUE,
  fecha_contratacion DATE         NOT NULL,
  foto               VARCHAR(120)
);

CREATE TABLE cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(60)  NOT NULL,
  apellidos  VARCHAR(80)  NOT NULL,
  telefono   VARCHAR(15)  NOT NULL,
  email      VARCHAR(100) UNIQUE,
  direccion  VARCHAR(150)
);

CREATE TABLE vehiculo (
  id_vehiculo INT AUTO_INCREMENT PRIMARY KEY,
  id_cliente  INT         NOT NULL,
  placa       VARCHAR(12) NOT NULL UNIQUE,
  marca       VARCHAR(40) NOT NULL,
  modelo      VARCHAR(40) NOT NULL,
  anio        INT         NOT NULL,
  color       VARCHAR(30),
  foto        VARCHAR(120),
  CONSTRAINT ck_vehiculo_anio CHECK (anio BETWEEN 1950 AND 2100),
  -- RESTRICT: un cliente con vehículos registrados no se puede borrar por accidente.
  CONSTRAINT fk_vehiculo_cliente FOREIGN KEY (id_cliente)
    REFERENCES cliente(id_cliente) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Tabla intermedia N:M entre vehiculo y tipo_servicio, con atributos propios
-- (fecha, estado, costo) y el responsable y herramienta que se usan.
CREATE TABLE orden_servicio (
  id_orden         INT AUTO_INCREMENT PRIMARY KEY,
  id_vehiculo      INT  NOT NULL,
  id_tipo_servicio INT  NOT NULL,
  id_empleado      INT  NOT NULL,
  id_herramienta   INT  NULL,
  fecha_ingreso    DATE NOT NULL,
  estado           ENUM('Pendiente','En proceso','Terminado','Entregado') NOT NULL DEFAULT 'Pendiente',
  observaciones    VARCHAR(255),
  -- RESTRICT: no se borra un vehículo, servicio o empleado que tenga órdenes (historial).
  CONSTRAINT fk_orden_vehiculo FOREIGN KEY (id_vehiculo)
    REFERENCES vehiculo(id_vehiculo) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_orden_servicio FOREIGN KEY (id_tipo_servicio)
    REFERENCES tipo_servicio(id_tipo_servicio) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_orden_empleado FOREIGN KEY (id_empleado)
    REFERENCES empleado(id_empleado) ON DELETE RESTRICT ON UPDATE CASCADE,
  -- SET NULL: si una herramienta se da de baja, la orden histórica se conserva.
  CONSTRAINT fk_orden_herramienta FOREIGN KEY (id_herramienta)
    REFERENCES herramienta(id_herramienta) ON DELETE SET NULL ON UPDATE CASCADE
);

-- ---------- ALTER TABLE ----------
ALTER TABLE orden_servicio ADD COLUMN costo DECIMAL(10,2) NOT NULL DEFAULT 0;
ALTER TABLE orden_servicio ADD CONSTRAINT ck_orden_costo CHECK (costo >= 0);
ALTER TABLE herramienta    ADD INDEX idx_herramienta_estado (estado);
ALTER TABLE vehiculo       ADD INDEX idx_vehiculo_marca (marca);
ALTER TABLE cliente        MODIFY telefono VARCHAR(20) NOT NULL;

-- ---------- Bitácora (la llenan los triggers; no cuenta en el mínimo de tablas) ----------
CREATE TABLE bitacora_orden (
  id_bitacora     INT AUTO_INCREMENT PRIMARY KEY,
  id_orden        INT          NOT NULL,
  estado_anterior VARCHAR(20),
  estado_nuevo    VARCHAR(20),
  usuario         VARCHAR(80)  NOT NULL,
  fecha           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Vistas (2.6): la app las usa como fuente de reportes ----------
CREATE VIEW v_ordenes_detalle AS
SELECT o.id_orden, o.fecha_ingreso, o.estado, o.costo,
       v.placa, CONCAT(v.marca,' ',v.modelo) AS vehiculo,
       CONCAT(c.nombre,' ',c.apellidos)      AS cliente,
       s.nombre                              AS servicio,
       CONCAT(e.nombre,' ',e.apellidos)      AS responsable,
       h.nombre                              AS herramienta
FROM orden_servicio o
INNER JOIN vehiculo v       ON v.id_vehiculo = o.id_vehiculo
INNER JOIN cliente c        ON c.id_cliente = v.id_cliente
INNER JOIN tipo_servicio s  ON s.id_tipo_servicio = o.id_tipo_servicio
INNER JOIN empleado e       ON e.id_empleado = o.id_empleado
LEFT  JOIN herramienta h    ON h.id_herramienta = o.id_herramienta;

CREATE VIEW v_vehiculos_cliente AS
SELECT v.id_vehiculo, v.placa, v.marca, v.modelo, v.anio, v.color,
       CONCAT(c.nombre,' ',c.apellidos) AS cliente, c.telefono
FROM vehiculo v
INNER JOIN cliente c ON c.id_cliente = v.id_cliente;

CREATE VIEW v_herramientas_uso AS
SELECT h.id_herramienta, h.nombre, h.marca, h.codigo, h.cantidad_disponible, h.estado,
       COUNT(o.id_orden) AS ordenes_en_proceso
FROM herramienta h
LEFT JOIN orden_servicio o ON o.id_herramienta = h.id_herramienta AND o.estado = 'En proceso'
GROUP BY h.id_herramienta, h.nombre, h.marca, h.codigo, h.cantidad_disponible, h.estado;
