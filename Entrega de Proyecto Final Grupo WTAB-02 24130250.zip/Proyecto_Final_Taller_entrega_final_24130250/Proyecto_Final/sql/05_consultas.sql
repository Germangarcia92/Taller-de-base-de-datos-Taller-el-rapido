-- ============================================================
--  05_consultas.sql : consultas de la Competencia 2
--  (la app C# usa estas mismas consultas, parametrizadas)
-- ============================================================
USE taller_mecanico;

-- 2.2 WHERE, LIKE, BETWEEN, IN
SELECT * FROM cliente WHERE nombre LIKE 'M%' OR apellidos LIKE '%ez';
SELECT * FROM vehiculo WHERE anio BETWEEN 2015 AND 2020 AND marca IN ('Toyota','Nissan','Honda');
SELECT * FROM orden_servicio
WHERE fecha_ingreso BETWEEN '2026-11-01' AND '2026-11-15' AND estado IN ('Pendiente','En proceso');

-- 2.3 Funciones, conversión, agrupamiento y ordenamiento (reporte)
CALL sp_reporte_servicios('2026-10-01', '2026-11-30', 1);
SELECT UPPER(marca) AS marca, COUNT(*) AS vehiculos, CAST(AVG(anio) AS DECIMAL(6,1)) AS anio_promedio
FROM vehiculo GROUP BY marca HAVING COUNT(*) >= 1 ORDER BY vehiculos DESC, marca;

-- 2.4 JOINs
-- INNER JOIN 1: vehículos con su dueño
SELECT v.placa, v.marca, v.modelo, CONCAT(c.nombre,' ',c.apellidos) AS cliente
FROM vehiculo v INNER JOIN cliente c ON c.id_cliente = v.id_cliente ORDER BY c.apellidos;
-- INNER JOIN 2: órdenes con vehículo, servicio y responsable
SELECT o.id_orden, v.placa, s.nombre AS servicio, CONCAT(e.nombre,' ',e.apellidos) AS responsable, o.estado
FROM orden_servicio o
INNER JOIN vehiculo v      ON v.id_vehiculo = o.id_vehiculo
INNER JOIN tipo_servicio s ON s.id_tipo_servicio = o.id_tipo_servicio
INNER JOIN empleado e      ON e.id_empleado = o.id_empleado;
-- INNER JOIN 3: servicios y cuántas órdenes se han hecho
SELECT s.nombre, COUNT(o.id_orden) AS ordenes
FROM tipo_servicio s INNER JOIN orden_servicio o ON o.id_tipo_servicio = s.id_tipo_servicio
GROUP BY s.nombre ORDER BY ordenes DESC;
-- LEFT JOIN: todos los empleados, incluso los que no tienen órdenes
SELECT CONCAT(e.nombre,' ',e.apellidos) AS responsable, e.puesto, COUNT(o.id_orden) AS ordenes
FROM empleado e LEFT JOIN orden_servicio o ON o.id_empleado = e.id_empleado
GROUP BY e.id_empleado, e.nombre, e.apellidos, e.puesto ORDER BY ordenes DESC, responsable;

-- 2.5 Subconsultas
-- En WHERE: servicios con precio mayor al promedio
SELECT nombre, precio_base FROM tipo_servicio
WHERE precio_base > (SELECT AVG(precio_base) FROM tipo_servicio) ORDER BY precio_base DESC;
-- Correlacionada: última visita de cada cliente
SELECT CONCAT(c.nombre,' ',c.apellidos) AS cliente,
       (SELECT MAX(o.fecha_ingreso) FROM orden_servicio o
        INNER JOIN vehiculo v ON v.id_vehiculo = o.id_vehiculo
        WHERE v.id_cliente = c.id_cliente) AS ultima_visita
FROM cliente c ORDER BY ultima_visita DESC;
-- En FROM: empleados con más órdenes que el promedio
SELECT CONCAT(e.nombre,' ',e.apellidos) AS responsable, t.total
FROM empleado e
INNER JOIN (SELECT id_empleado, COUNT(*) AS total FROM orden_servicio GROUP BY id_empleado) t
        ON t.id_empleado = e.id_empleado
WHERE t.total > (SELECT AVG(x.total) FROM (SELECT COUNT(*) AS total FROM orden_servicio GROUP BY id_empleado) x);

-- Operador de conjuntos (UNION): directorio de clientes y empleados
SELECT CONCAT(nombre,' ',apellidos) AS nombre, telefono, 'Cliente' AS tipo FROM cliente
UNION
SELECT CONCAT(nombre,' ',apellidos), telefono, 'Empleado' FROM empleado
ORDER BY tipo, nombre;

-- 5.2 Uso de funciones definidas por el usuario
SELECT CONCAT(nombre,' ',apellidos) AS empleado, fn_antiguedad_anios(fecha_contratacion) AS anios FROM empleado;
SELECT nombre, precio_base, fn_costo_con_iva(precio_base) AS precio_con_iva FROM tipo_servicio;
SELECT id_cliente, CONCAT(nombre,' ',apellidos) AS cliente, fn_ordenes_cliente(id_cliente) AS ordenes FROM cliente;

-- 2.6 Vistas
SELECT * FROM v_ordenes_detalle;
SELECT * FROM v_vehiculos_cliente;
SELECT * FROM v_herramientas_uso;
